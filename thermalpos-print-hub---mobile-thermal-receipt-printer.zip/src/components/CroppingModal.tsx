import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  X,
  RotateCw,
  RotateCcw,
  Sliders,
  Check,
  Printer,
  FileText,
  Maximize2,
  ZoomIn,
  ZoomOut,
  Sparkles,
} from 'lucide-react';
import { ImageProcessingOptions, PaperWidth } from '../types';
import { processThermalMonochrome } from '../utils/dithering';

interface CroppingModalProps {
  isOpen: boolean;
  imageSrc: string;
  paperWidth: PaperWidth;
  onClose: () => void;
  onConfirmCrop: (croppedDataUrl: string, options: ImageProcessingOptions) => void;
  onDirectBwPrint: (bitmapCanvas: HTMLCanvasElement, options: ImageProcessingOptions) => void;
  onExtractOcr: (croppedDataUrl: string) => void;
}

export const CroppingModal: React.FC<CroppingModalProps> = ({
  isOpen,
  imageSrc,
  paperWidth,
  onClose,
  onConfirmCrop,
  onDirectBwPrint,
  onExtractOcr,
}) => {
  const [rotation, setRotation] = useState<number>(0);
  const [zoom, setZoom] = useState<number>(1);
  const [options, setOptions] = useState<ImageProcessingOptions>({
    ditherType: 'floyd_steinberg',
    threshold: 128,
    contrast: 15,
    brightness: 0,
    invert: false,
    rotation: 0,
  });

  const [showThermalPreview, setShowThermalPreview] = useState(false);
  const [aspectRatioMode, setAspectRatioMode] = useState<'free' | '58mm' | '80mm' | '1:1'>('free');

  // Interactive crop box coords relative to container [0..1]
  const [crop, setCrop] = useState({
    x: 0.05,
    y: 0.05,
    width: 0.9,
    height: 0.9,
  });

  const [isDragging, setIsDragging] = useState<string | null>(null);
  const dragStartRef = useRef<{ mouseX: number; mouseY: number; initialCrop: typeof crop }>({
    mouseX: 0,
    mouseY: 0,
    initialCrop: crop,
  });

  const containerRef = useRef<HTMLDivElement>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement>(null);
  const sourceImageRef = useRef<HTMLImageElement | null>(null);

  // Load source image
  useEffect(() => {
    if (!imageSrc) return;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      sourceImageRef.current = img;
      // Reset crop to central 90%
      setCrop({ x: 0.05, y: 0.05, width: 0.9, height: 0.9 });
      renderThermalLivePreview();
    };
    img.src = imageSrc;
  }, [imageSrc]);

  // Adjust crop aspect ratio when mode changes
  const applyAspectRatio = useCallback((mode: 'free' | '58mm' | '80mm' | '1:1') => {
    setAspectRatioMode(mode);
    if (mode === 'free') return;

    let targetRatio = 1;
    if (mode === '58mm') targetRatio = 384 / 600; // ~0.64
    if (mode === '80mm') targetRatio = 576 / 800; // ~0.72
    if (mode === '1:1') targetRatio = 1.0;

    setCrop((prev) => {
      const newHeight = Math.min(0.9, prev.width / targetRatio);
      return {
        ...prev,
        height: Math.max(0.1, newHeight),
      };
    });
  }, []);

  // Generate cropped canvas
  const getCroppedCanvas = useCallback((): HTMLCanvasElement | null => {
    const img = sourceImageRef.current;
    if (!img) return null;

    const cropCanvas = document.createElement('canvas');
    const sourceCropX = crop.x * img.naturalWidth;
    const sourceCropY = crop.y * img.naturalHeight;
    const sourceCropW = crop.width * img.naturalWidth;
    const sourceCropH = crop.height * img.naturalHeight;

    cropCanvas.width = Math.max(10, Math.round(sourceCropW));
    cropCanvas.height = Math.max(10, Math.round(sourceCropH));
    const ctx = cropCanvas.getContext('2d');
    if (!ctx) return null;

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, cropCanvas.width, cropCanvas.height);

    if (rotation !== 0) {
      ctx.save();
      ctx.translate(cropCanvas.width / 2, cropCanvas.height / 2);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.drawImage(
        img,
        sourceCropX,
        sourceCropY,
        sourceCropW,
        sourceCropH,
        -cropCanvas.width / 2,
        -cropCanvas.height / 2,
        cropCanvas.width,
        cropCanvas.height
      );
      ctx.restore();
    } else {
      ctx.drawImage(
        img,
        sourceCropX,
        sourceCropY,
        sourceCropW,
        sourceCropH,
        0,
        0,
        cropCanvas.width,
        cropCanvas.height
      );
    }

    return cropCanvas;
  }, [crop, rotation]);

  // Live thermal preview
  const renderThermalLivePreview = useCallback(() => {
    if (!showThermalPreview) return;
    const cropped = getCroppedCanvas();
    if (!cropped || !previewCanvasRef.current) return;

    try {
      const processed = processThermalMonochrome(
        cropped,
        cropped.width,
        cropped.height,
        paperWidth,
        options
      );

      const previewCanvas = previewCanvasRef.current;
      previewCanvas.width = processed.width;
      previewCanvas.height = processed.height;
      const pctx = previewCanvas.getContext('2d');
      if (pctx) {
        pctx.drawImage(processed.canvas, 0, 0);
      }
    } catch (e) {
      console.error('Thermal preview error', e);
    }
  }, [getCroppedCanvas, options, paperWidth, showThermalPreview]);

  useEffect(() => {
    renderThermalLivePreview();
  }, [renderThermalLivePreview]);

  // Mouse & Touch Dragging Handlers
  const handlePointerDown = (e: React.PointerEvent, handleType: string) => {
    e.stopPropagation();
    setIsDragging(handleType);
    dragStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      initialCrop: { ...crop },
    };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const dx = (e.clientX - dragStartRef.current.mouseX) / rect.width;
    const dy = (e.clientY - dragStartRef.current.mouseY) / rect.height;

    const initial = dragStartRef.current.initialCrop;

    setCrop((prev) => {
      let { x, y, width, height } = initial;

      if (isDragging === 'move') {
        x = Math.max(0, Math.min(1 - width, x + dx));
        y = Math.max(0, Math.min(1 - height, y + dy));
      } else if (isDragging === 'se') {
        width = Math.max(0.1, Math.min(1 - x, initial.width + dx));
        height = Math.max(0.1, Math.min(1 - y, initial.height + dy));
      } else if (isDragging === 'sw') {
        const newX = Math.max(0, Math.min(initial.x + initial.width - 0.1, initial.x + dx));
        width = initial.x + initial.width - newX;
        x = newX;
        height = Math.max(0.1, Math.min(1 - y, initial.height + dy));
      } else if (isDragging === 'ne') {
        const newY = Math.max(0, Math.min(initial.y + initial.height - 0.1, initial.y + dy));
        height = initial.y + initial.height - newY;
        y = newY;
        width = Math.max(0.1, Math.min(1 - x, initial.width + dx));
      } else if (isDragging === 'nw') {
        const newX = Math.max(0, Math.min(initial.x + initial.width - 0.1, initial.x + dx));
        const newY = Math.max(0, Math.min(initial.y + initial.height - 0.1, initial.y + dy));
        width = initial.x + initial.width - newX;
        height = initial.y + initial.height - newY;
        x = newX;
        y = newY;
      }

      return { x, y, width, height };
    });
  };

  const handlePointerUp = () => {
    setIsDragging(null);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl max-h-[92vh] rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Maximize2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Adjust & Crop Receipt Image
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono">
              {paperWidth}
            </span>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Editor Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Main Visual Workspace */}
          <div className="relative w-full aspect-[4/3] sm:aspect-[16/10] bg-slate-950 rounded-2xl overflow-hidden flex items-center justify-center select-none touch-none">
            {showThermalPreview ? (
              /* Thermal Head Live Dot Preview */
              <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-slate-900 overflow-auto">
                <div className="text-[11px] text-slate-400 font-mono mb-2 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>1-Bit Monochrome Thermal Print Head Preview ({paperWidth})</span>
                </div>
                <div className="p-3 bg-white rounded-lg shadow-inner max-w-full max-h-[80%] overflow-auto">
                  <canvas
                    ref={previewCanvasRef}
                    className="pixelated max-w-full object-contain mx-auto border border-dashed border-slate-300"
                    style={{ width: paperWidth === '58mm' ? '280px' : '360px' }}
                  />
                </div>
              </div>
            ) : (
              /* Interactive Crop Canvas */
              <div
                ref={containerRef}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                className="relative w-full h-full flex items-center justify-center overflow-hidden cursor-crosshair"
              >
                <img
                  src={imageSrc}
                  alt="Crop preview"
                  className="max-w-full max-h-full object-contain pointer-events-none select-none transition-transform"
                  style={{
                    transform: `rotate(${rotation}deg) scale(${zoom})`,
                  }}
                />

                {/* Shaded backdrop & active crop rectangle */}
                <div
                  className="absolute border-2 border-emerald-400 bg-emerald-500/10 shadow-[0_0_0_9999px_rgba(0,0,0,0.65)] cursor-move"
                  style={{
                    left: `${crop.x * 100}%`,
                    top: `${crop.y * 100}%`,
                    width: `${crop.width * 100}%`,
                    height: `${crop.height * 100}%`,
                  }}
                  onPointerDown={(e) => handlePointerDown(e, 'move')}
                >
                  {/* Grid lines for precision receipt alignment */}
                  <div className="w-full h-full grid grid-cols-3 grid-rows-3 pointer-events-none opacity-40">
                    <div className="border-r border-b border-emerald-300"></div>
                    <div className="border-r border-b border-emerald-300"></div>
                    <div className="border-b border-emerald-300"></div>
                    <div className="border-r border-b border-emerald-300"></div>
                    <div className="border-r border-b border-emerald-300"></div>
                    <div className="border-b border-emerald-300"></div>
                    <div className="border-r border-emerald-300"></div>
                    <div className="border-r border-emerald-300"></div>
                    <div></div>
                  </div>

                  {/* Corner Handles */}
                  <div
                    onPointerDown={(e) => handlePointerDown(e, 'nw')}
                    className="absolute -top-2.5 -left-2.5 w-6 h-6 bg-white border-2 border-emerald-500 rounded-full shadow-md cursor-nwse-resize"
                  />
                  <div
                    onPointerDown={(e) => handlePointerDown(e, 'ne')}
                    className="absolute -top-2.5 -right-2.5 w-6 h-6 bg-white border-2 border-emerald-500 rounded-full shadow-md cursor-nesw-resize"
                  />
                  <div
                    onPointerDown={(e) => handlePointerDown(e, 'sw')}
                    className="absolute -bottom-2.5 -left-2.5 w-6 h-6 bg-white border-2 border-emerald-500 rounded-full shadow-md cursor-nesw-resize"
                  />
                  <div
                    onPointerDown={(e) => handlePointerDown(e, 'se')}
                    className="absolute -bottom-2.5 -right-2.5 w-6 h-6 bg-white border-2 border-emerald-500 rounded-full shadow-md cursor-nwse-resize"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Quick Toolbar (Rotation, Aspect Ratio, Live Dot Toggle) */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
            {/* Aspect Presets */}
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
              {(['free', '58mm', '80mm', '1:1'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => applyAspectRatio(mode)}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                    aspectRatioMode === mode
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  {mode === 'free' ? 'Free' : mode}
                </button>
              ))}
            </div>

            {/* Transform Controls */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setRotation((r) => (r - 90 + 360) % 360)}
                className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-center"
                title="Rotate 90° CCW"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setRotation((r) => (r + 90) % 360)}
                className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-center"
                title="Rotate 90° CW"
              >
                <RotateCw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setZoom((z) => Math.max(0.5, z - 0.2))}
                className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-center"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                onClick={() => setZoom((z) => Math.min(2.5, z + 0.2))}
                className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-center"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={() => setShowThermalPreview(!showThermalPreview)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                  showThermalPreview
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>{showThermalPreview ? 'Editing Crop' : 'Thermal Preview'}</span>
              </button>
            </div>
          </div>

          {/* Dithering & Threshold Fine Tuning */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl border border-slate-200/60 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-medium text-slate-700 dark:text-slate-300">
              <span className="font-semibold">Thermal Dithering Algorithm</span>
              <div className="flex gap-2">
                {(['floyd_steinberg', 'threshold', 'atkinson'] as const).map((dither) => (
                  <button
                    key={dither}
                    onClick={() => setOptions((prev) => ({ ...prev, ditherType: dither }))}
                    className={`px-2 py-0.5 rounded capitalize transition-colors ${
                      options.ditherType === dither
                        ? 'bg-emerald-600 text-white font-semibold'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {dither.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <div className="flex justify-between mb-1 text-slate-600 dark:text-slate-400">
                  <span>Contrast ({options.contrast})</span>
                  <span>{options.contrast > 0 ? `+${options.contrast}` : options.contrast}</span>
                </div>
                <input
                  type="range"
                  min="-50"
                  max="50"
                  value={options.contrast}
                  onChange={(e) => setOptions((prev) => ({ ...prev, contrast: Number(e.target.value) }))}
                  className="w-full accent-emerald-600"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1 text-slate-600 dark:text-slate-400">
                  <span>Binarize Threshold ({options.threshold})</span>
                  <span>{options.threshold}</span>
                </div>
                <input
                  type="range"
                  min="40"
                  max="220"
                  value={options.threshold}
                  onChange={(e) => setOptions((prev) => ({ ...prev, threshold: Number(e.target.value) }))}
                  className="w-full accent-emerald-600"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Modal Actions Footer with TWO DISTINCT PRINTING MODES */}
        <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Mode 1: Direct B&W Image Printing */}
            <button
              onClick={() => {
                const cropped = getCroppedCanvas();
                if (cropped) {
                  const processed = processThermalMonochrome(
                    cropped,
                    cropped.width,
                    cropped.height,
                    paperWidth,
                    options
                  );
                  onDirectBwPrint(processed.canvas, options);
                }
              }}
              className="h-10 px-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
            >
              <Printer className="w-4 h-4 text-emerald-400" />
              <span>Direct B&W Print</span>
            </button>

            {/* Mode 2: OCR Text Extraction */}
            <button
              onClick={() => {
                const cropped = getCroppedCanvas();
                if (cropped) {
                  onExtractOcr(cropped.toDataURL('image/png'));
                }
              }}
              className="h-10 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm shadow-emerald-600/20 active:scale-95 transition-all"
            >
              <FileText className="w-4 h-4" />
              <span>Extract Text (OCR)</span>
            </button>

            {/* Confirm Crop to Canvas */}
            <button
              onClick={() => {
                const cropped = getCroppedCanvas();
                if (cropped) {
                  onConfirmCrop(cropped.toDataURL('image/png'), options);
                }
              }}
              className="h-10 px-3.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold flex items-center gap-1.5 transition-all"
            >
              <Check className="w-4 h-4 text-emerald-600" />
              <span>Apply Crop</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
