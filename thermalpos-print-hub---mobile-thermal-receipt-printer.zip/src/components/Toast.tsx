import React from 'react';
import { useApp } from '../context/AppContext';
import { CheckCircle2, AlertCircle, Info } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-2 pointer-events-none w-full max-w-sm px-4">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={`pointer-events-auto flex items-center gap-2.5 px-4 py-2.5 rounded-2xl shadow-xl text-xs font-semibold backdrop-blur-md border animate-in slide-in-from-top-4 fade-in duration-200 ${
            toast.type === 'success'
              ? 'bg-slate-900/90 text-white border-emerald-500/30'
              : toast.type === 'error'
              ? 'bg-rose-900/90 text-white border-rose-500/30'
              : 'bg-slate-900/90 text-white border-slate-700/50'
          }`}
        >
          {toast.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : toast.type === 'error' ? (
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          ) : (
            <Info className="w-4 h-4 text-sky-400 shrink-0" />
          )}
          <span className="truncate">{toast.message}</span>
        </div>
      ))}
    </div>
  );
};
