import React, { useState, useRef, useEffect } from 'react';
import QRCode from 'qrcode';
import JsBarcode from 'jsbarcode';
import {
  QrCode,
  Barcode as BarcodeIcon,
  Printer,
  Sparkles,
  Link,
  CreditCard,
  Wifi,
  Package,
  Layers,
  Sliders,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { BarcodeQrConfig } from '../types';

export const QrBarcodeTab: React.FC = () => {
  const {
    printerSettings,
    togglePaperWidth,
    executePrint,
    isPrinting,
    showToast,
    businessSettings,
  } = useApp();

  const [mode, setMode] = useState<'qr' | 'barcode'>('qr');

  // QR config
  const [qrText, setQrText] = useState('https://quickpay.pos/pay?ref=940182');
  const [qrCaption, setQrCaption] = useState('Scan with Phone Camera to Pay');
  const [qrEcc, setQrEcc] = useState<'L' | 'M' | 'Q' | 'H'>('M');
  const [qrScale, setQrScale] = useState(4); // 2 to 8

  // Barcode config
  const [barcodeText, setBarcodeText] = useState('TXN-84910283');
  const [barcodeFormat, setBarcodeFormat] = useState<'CODE128' | 'EAN13' | 'EAN8' | 'UPC' | 'CODE39'>('CODE128');
  const [barcodeCaption, setBarcodeCaption] = useState('Item #84910283 / AHMAD POS');
  const [barcodeHeight, setBarcodeHeight] = useState(45);
  const [showBarcodeText, setShowBarcodeText] = useState(true);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const paperCanvasRef = useRef<HTMLCanvasElement>(null);

  // Quick preset templates
  const presets = [
    {
      title: 'UPI / Card Payment',
      type: 'qr' as const,
      text: 'upi://pay?pa=quickpay@bank&pn=AhmadQuickPay&am=50.00&cu=USD',
      caption: 'Scan & Pay $50.00 via UPI / Mobile Wallet',
    },
    {
      title: 'Wi-Fi Guest Access',
      type: 'qr' as const,
      text: 'WIFI:T:WPA;S:QuickPay_Guest;P:pos123456;;',
      caption: 'Guest Wi-Fi: QuickPay_Guest',
    },
    {
      title: 'Product SKU (Code128)',
      type: 'barcode' as const,
      text: 'SKU-892401',
      caption: 'Inventory Barcode: SKU-892401',
    },
    {
      title: 'Parcel Tracking Code',
      type: 'barcode' as const,
      text: 'TRK940182741',
      caption: 'Express Courier Airway Bill',
    },
  ];

  // Render generator preview
  useEffect(() => {
    const renderCode = (targetCanvas: HTMLCanvasElement | null, isForPaperSlip: boolean) => {
      if (!targetCanvas) return;

      if (mode === 'qr') {
        const sizePx = isForPaperSlip
          ? (printerSettings.paperWidth === '58mm' ? 160 : 210)
          : qrScale * 38;

        QRCode.toCanvas(
          targetCanvas,
          qrText || 'ThermalPOS',
          {
            width: sizePx,
            margin: 1,
            errorCorrectionLevel: qrEcc,
            color: { dark: '#000000', light: '#ffffff' },
          },
          (err) => {
            if (err) console.error('QR Render failed', err);
          }
        );
      } else {
        // 1D Barcode
        try {
          JsBarcode(targetCanvas, barcodeText || '12345678', {
            format: barcodeFormat,
            width: isForPaperSlip ? (printerSettings.paperWidth === '58mm' ? 1.4 : 1.9) : 2,
            height: isForPaperSlip ? Math.min(barcodeHeight, 48) : barcodeHeight,
            displayValue: showBarcodeText,
            font: 'JetBrains Mono',
            fontSize: 11,
            margin: 6,
            background: '#ffffff',
            lineColor: '#000000',
          });
        } catch (e: any) {
          console.warn('Invalid barcode for format:', e);
        }
      }
    };

    renderCode(canvasRef.current, false);
    renderCode(paperCanvasRef.current, true);
  }, [
    mode,
    qrText,
    qrCaption,
    qrEcc,
    qrScale,
    barcodeText,
    barcodeFormat,
    barcodeCaption,
    barcodeHeight,
    showBarcodeText,
    printerSettings.paperWidth,
  ]);

  const handlePrintCode = () => {
    const title = mode === 'qr' ? `QR Code: ${qrCaption || qrText}` : `Barcode: ${barcodeCaption || barcodeText}`;
    executePrint(title, 'barcode_qr', {
      type: mode,
      content: mode === 'qr' ? qrText : barcodeText,
      caption: mode === 'qr' ? qrCaption : barcodeCaption,
    });
  };

  return (
    <div className="max-w-6xl mx-auto pb-24 px-3 sm:px-4 pt-3 space-y-6">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center">
            {mode === 'qr' ? <QrCode className="w-5 h-5" /> : <BarcodeIcon className="w-5 h-5" />}
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Instant Text-to-QR & Barcode Tool
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Generate QR codes and 1D barcodes and print them instantly on 58mm/80mm rolls.
            </p>
          </div>
        </div>

        {/* Paper switch */}
        <button
          onClick={() => togglePaperWidth()}
          className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 transition-colors"
        >
          <Sliders className="w-3.5 h-3.5 text-purple-600" />
          <span>Paper: {printerSettings.paperWidth}</span>
        </button>
      </div>

      {/* Mode Switcher */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-200/70 dark:bg-slate-800/80 rounded-2xl max-w-sm">
        <button
          onClick={() => setMode('qr')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            mode === 'qr'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <QrCode className="w-4 h-4 text-purple-600" />
          <span>QR Code</span>
        </button>

        <button
          onClick={() => setMode('barcode')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            mode === 'barcode'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <BarcodeIcon className="w-4 h-4 text-emerald-600" />
          <span>1D Barcode</span>
        </button>
      </div>

      {/* Quick Templates Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <span className="text-xs text-slate-500 font-medium whitespace-nowrap">Templates:</span>
        {presets.map((preset, idx) => (
          <button
            key={idx}
            onClick={() => {
              setMode(preset.type);
              if (preset.type === 'qr') {
                setQrText(preset.text);
                setQrCaption(preset.caption);
              } else {
                setBarcodeText(preset.text);
                setBarcodeCaption(preset.caption);
              }
              showToast(`Loaded ${preset.title}`, 'info');
            }}
            className="whitespace-nowrap px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-purple-500 text-xs text-slate-700 dark:text-slate-300 font-medium shrink-0 transition-all flex items-center gap-1.5"
          >
            {preset.type === 'qr' ? <QrCode className="w-3.5 h-3.5 text-purple-500" /> : <BarcodeIcon className="w-3.5 h-3.5 text-emerald-500" />}
            <span>{preset.title}</span>
          </button>
        ))}
      </div>

      {/* 2-Column Responsive Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Generator Controls Column (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              {mode === 'qr' ? 'QR Code Configuration' : '1D Barcode Configuration'}
            </h3>

            {mode === 'qr' ? (
              /* QR SETTINGS */
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                    Content / URL / Payment String:
                  </label>
                  <textarea
                    rows={3}
                    value={qrText}
                    onChange={(e) => setQrText(e.target.value)}
                    placeholder="Enter URL, text, or payment link..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-xs focus:outline-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                    Caption / Instructions (Printed below QR):
                  </label>
                  <input
                    type="text"
                    value={qrCaption}
                    onChange={(e) => setQrCaption(e.target.value)}
                    placeholder="e.g. Scan to Pay / Visit Website"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs focus:outline-purple-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 mb-1">
                      Error Correction Level:
                    </label>
                    <div className="grid grid-cols-4 gap-1">
                      {(['L', 'M', 'Q', 'H'] as const).map((lvl) => (
                        <button
                          key={lvl}
                          type="button"
                          onClick={() => setQrEcc(lvl)}
                          className={`py-1.5 rounded-lg font-bold transition-all ${
                            qrEcc === lvl
                              ? 'bg-purple-600 text-white shadow-xs'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          {lvl}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 mb-1">
                      Module Scale: ({qrScale}x)
                    </label>
                    <input
                      type="range"
                      min="2"
                      max="7"
                      value={qrScale}
                      onChange={(e) => setQrScale(Number(e.target.value))}
                      className="w-full accent-purple-600 mt-2"
                    />
                  </div>
                </div>
              </div>
            ) : (
              /* BARCODE SETTINGS */
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                    Barcode Value:
                  </label>
                  <input
                    type="text"
                    value={barcodeText}
                    onChange={(e) => setBarcodeText(e.target.value)}
                    placeholder="e.g. 84910283 or SKU-001"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-xs focus:outline-emerald-500 font-bold"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                    Caption (Printed above/below):
                  </label>
                  <input
                    type="text"
                    value={barcodeCaption}
                    onChange={(e) => setBarcodeCaption(e.target.value)}
                    placeholder="e.g. Product Name or Tracking ID"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs focus:outline-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 mb-1">
                      Barcode Symbology:
                    </label>
                    <select
                      value={barcodeFormat}
                      onChange={(e) => setBarcodeFormat(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs font-semibold"
                    >
                      <option value="CODE128">Code 128 (Alphanumeric)</option>
                      <option value="EAN13">EAN-13 (13 Digits)</option>
                      <option value="EAN8">EAN-8 (8 Digits)</option>
                      <option value="UPC">UPC-A (12 Digits)</option>
                      <option value="CODE39">Code 39</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 mb-1">
                      Barcode Height ({barcodeHeight}px):
                    </label>
                    <input
                      type="range"
                      min="25"
                      max="75"
                      value={barcodeHeight}
                      onChange={(e) => setBarcodeHeight(Number(e.target.value))}
                      className="w-full accent-emerald-600 mt-2"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="showVal"
                    checked={showBarcodeText}
                    onChange={(e) => setShowBarcodeText(e.target.checked)}
                    className="rounded accent-emerald-600 w-4 h-4"
                  />
                  <label htmlFor="showVal" className="text-slate-700 dark:text-slate-300 font-medium cursor-pointer">
                    Display human-readable text below barcode lines
                  </label>
                </div>
              </div>
            )}

            {/* Print Action Button */}
            <button
              onClick={handlePrintCode}
              disabled={isPrinting}
              className={`w-full h-12 rounded-xl text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.98] ${
                mode === 'qr'
                  ? 'bg-purple-600 hover:bg-purple-500 shadow-purple-600/25'
                  : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/25'
              }`}
            >
              <Printer className="w-4 h-4" />
              <span>
                {mode === 'qr' ? 'Print QR Slip Instantly' : 'Print Barcode Slip Instantly'}
              </span>
            </button>
          </div>
        </div>

        {/* Live Thermal Paper Roll Simulation (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-200 dark:bg-slate-950 p-4 sm:p-6 rounded-3xl border border-slate-300 dark:border-slate-800 flex flex-col items-center">
            <div className="w-full flex items-center justify-between text-xs text-slate-500 font-mono mb-3 px-1">
              <span>THERMAL SLIP PREVIEW</span>
              <span>{printerSettings.paperWidth}</span>
            </div>

            {/* Thermal Paper Slip */}
            <div
              className={`bg-white text-black p-4 rounded-sm shadow-xl border-x border-slate-300 font-thermal text-xs text-center select-text ${
                printerSettings.paperWidth === '58mm' ? 'w-full max-w-[280px]' : 'w-full max-w-[360px]'
              }`}
            >
              <div className="h-1.5 -mx-4 -mt-4 receipt-jagged-top mb-3" />

              <div className="font-extrabold uppercase text-xs tracking-wider border-b border-black pb-1 mb-2">
                {businessSettings.shopName}
              </div>

              <div className="text-[10px] text-neutral-600 mb-2">
                {new Date().toLocaleDateString()} · {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>

              {/* Rendered Canvas on Paper */}
              <div className="py-2 flex flex-col items-center justify-center">
                <canvas ref={paperCanvasRef} className="max-w-full" />
              </div>

              {/* Caption on slip */}
              <div className="font-semibold text-xs mt-1 px-2 leading-tight">
                {mode === 'qr' ? qrCaption : barcodeCaption}
              </div>

              <div className="text-[10px] font-mono text-neutral-500 mt-1 truncate px-2">
                {mode === 'qr' ? qrText : barcodeText}
              </div>

              <div className="mt-3 pt-2 border-t border-dashed border-black text-[9px] text-neutral-600">
                *** SCAN WITH ANY STANDARD READER ***
              </div>

              <div className="h-2 -mx-4 -mb-4 receipt-jagged-bottom mt-3" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
