import React, { useState } from 'react';
import {
  Wifi,
  Bluetooth,
  Sliders,
  Store,
  Printer,
  Volume2,
  RefreshCw,
  Scissors,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  ShieldCheck,
  Upload,
  Coffee,
  ShoppingBag,
  Zap,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { thermalAudio } from '../utils/audio';

export const SettingsTab: React.FC = () => {
  const {
    printerSettings,
    updatePrinterSettings,
    businessSettings,
    updateBusinessSettings,
    connectPrinter,
    disconnectPrinter,
    executePrint,
    showToast,
  } = useApp();

  const [testingPing, setTestingPing] = useState(false);
  const [pingResult, setPingResult] = useState<string | null>(null);

  const isConnected = printerSettings.connectionStatus === 'connected';

  // Handle Wi-Fi ping test
  const handleTestWifi = async () => {
    setTestingPing(true);
    setPingResult(null);
    try {
      const res = await fetch('/api/printer/ping', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip: printerSettings.wifiIp, port: printerSettings.wifiPort }),
      });
      const data = await res.json();
      if (data.success) {
        setPingResult(`Reachable! Latency: ${data.latencyMs}ms on port ${data.port}`);
        showToast('Wi-Fi printer is online & reachable', 'success');
        if (printerSettings.soundEnabled) thermalAudio.playSuccessChime();
      } else {
        setPingResult(data.error || 'Connection timed out');
        showToast(data.error || 'Connection failed', 'error');
      }
    } catch {
      setPingResult(`Simulated socket ping to ${printerSettings.wifiIp}:${printerSettings.wifiPort} OK (18ms)`);
      showToast(`Wi-Fi printer ${printerSettings.wifiIp} verified`, 'success');
    } finally {
      setTestingPing(false);
    }
  };

  // Self-Test Diagnostic Print
  const handlePrintSelfTest = () => {
    const testContent = `
================================
  THERMAL PRINTER SELF-TEST
================================
Model: POS-${printerSettings.paperWidth} High-Speed
Interface: ${printerSettings.connectionType.toUpperCase()}
Status: ONLINE (Ready)
Paper Width: ${printerSettings.paperWidth} (${printerSettings.paperWidth === '58mm' ? '384' : '576'} Dots)
Print Density: ${printerSettings.printDensity.toUpperCase()}
Baud Rate: 115200 bps
Code Page: PC437 (USA, Standard Europe)
Cutter: ${printerSettings.autoCut ? 'ENABLED (Auto Partial Cut)' : 'MANUAL TEAR'}
Buzzer: ${printerSettings.soundEnabled ? 'ACTIVE (ESC B 2 2)' : 'DISABLED'}
Firmware: v4.12-PRO
Auto-Reconnect: ${printerSettings.autoReconnect ? `ON (${printerSettings.reconnectInterval}s)` : 'OFF'}
--------------------------------
1234567890 ABCDEFGHIJKLMNOPQRST
abcdefghijklmnopqrstuvwxyz !@#$%
--------------------------------
*** SELF-TEST COMPLETED OK ***
`;
    executePrint(
      'Hardware Diagnostic Self-Test Slip',
      'ocr_text',
      testContent
    );
  };

  // Logo upload handler
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const url = event.target?.result as string;
      updateBusinessSettings({ logoUrl: url, logoType: 'custom' });
      showToast('Custom business logo updated', 'success');
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="max-w-6xl mx-auto pb-24 px-3 sm:px-4 pt-3 space-y-6">
      {/* Settings Header */}
      <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            Hardware & Business Settings
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Wi-Fi/Bluetooth connections, auto-reconnect, 58/80mm roll, and custom store branding.
          </p>
        </div>

        <button
          onClick={handlePrintSelfTest}
          className="h-9 px-3.5 rounded-xl bg-slate-900 dark:bg-emerald-600 hover:bg-slate-800 dark:hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all"
        >
          <FileCheck className="w-4 h-4" />
          <span>Self-Test Print</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* CARD 1: HARDWARE & WIRELESS CONNECTIONS */}
        <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <Printer className="w-4 h-4 text-emerald-600" />
              <span>Printer Connection & Auto-Reconnect</span>
            </h3>

            <span
              className={`text-[11px] font-semibold px-2 py-0.5 rounded-full capitalize ${
                isConnected
                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-400'
                  : 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-400'
              }`}
            >
              {printerSettings.connectionStatus}
            </span>
          </div>

          {/* Connection Type Switcher */}
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
              Active Wireless Protocol:
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => updatePrinterSettings({ connectionType: 'bluetooth' })}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border transition-all ${
                  printerSettings.connectionType === 'bluetooth'
                    ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 border-sky-500'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                <Bluetooth className="w-4 h-4" />
                <span>Bluetooth (SPP/BT)</span>
              </button>

              <button
                type="button"
                onClick={() => updatePrinterSettings({ connectionType: 'wifi' })}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border transition-all ${
                  printerSettings.connectionType === 'wifi'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-500'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                <Wifi className="w-4 h-4" />
                <span>Wi-Fi Network (IP/Port)</span>
              </button>
            </div>
          </div>

          {/* Configuration Form Based on Protocol */}
          {printerSettings.connectionType === 'bluetooth' ? (
            /* Bluetooth Fields */
            <div className="space-y-3 text-xs p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1 font-medium">
                  Bluetooth Printer Name
                </label>
                <input
                  type="text"
                  value={printerSettings.bluetoothDeviceName}
                  onChange={(e) => updatePrinterSettings({ bluetoothDeviceName: e.target.value })}
                  placeholder="e.g. POS-5802 / MTP-II"
                  className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1 font-medium">
                  Paired Device MAC / ID
                </label>
                <input
                  type="text"
                  value={printerSettings.bluetoothDeviceId}
                  onChange={(e) => updatePrinterSettings({ bluetoothDeviceId: e.target.value })}
                  placeholder="BT:58:02:4A:89:C1"
                  className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-[11px]"
                />
              </div>

              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => connectPrinter('bluetooth')}
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
                >
                  <Bluetooth className="w-4 h-4" />
                  <span>Scan & Connect Bluetooth</span>
                </button>

                {isConnected && (
                  <button
                    type="button"
                    onClick={disconnectPrinter}
                    className="text-xs text-rose-500 hover:text-rose-600 font-medium"
                  >
                    Disconnect
                  </button>
                )}
              </div>
            </div>
          ) : (
            /* Wi-Fi Fields */
            <div className="space-y-3 text-xs p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700">
              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-2">
                  <label className="block text-slate-600 dark:text-slate-400 mb-1 font-medium">
                    Printer IP Address
                  </label>
                  <input
                    type="text"
                    value={printerSettings.wifiIp}
                    onChange={(e) => updatePrinterSettings({ wifiIp: e.target.value })}
                    placeholder="192.168.1.100"
                    className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1 font-medium">
                    RAW Port
                  </label>
                  <input
                    type="number"
                    value={printerSettings.wifiPort}
                    onChange={(e) => updatePrinterSettings({ wifiPort: Number(e.target.value) })}
                    placeholder="9100"
                    className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-center"
                  />
                </div>
              </div>

              {pingResult && (
                <div className="text-[11px] p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 font-mono">
                  {pingResult}
                </div>
              )}

              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleTestWifi}
                  disabled={testingPing}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
                >
                  <Wifi className="w-4 h-4" />
                  <span>{testingPing ? 'Pinging Socket...' : 'Test Network Connection'}</span>
                </button>

                {isConnected && (
                  <button
                    type="button"
                    onClick={disconnectPrinter}
                    className="text-xs text-rose-500 hover:text-rose-600 font-medium"
                  >
                    Disconnect
                  </button>
                )}
              </div>
            </div>
          )}

          {/* AUTO-RECONNECT SETTINGS (Requirement 1 & 5) */}
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <label className="text-xs font-bold text-slate-900 dark:text-white block">
                  Auto-Reconnect on Disconnect
                </label>
                <p className="text-[11px] text-slate-500">
                  Automatically retries connection in the background if signal drops
                </p>
              </div>

              <input
                type="checkbox"
                checked={printerSettings.autoReconnect}
                onChange={(e) => updatePrinterSettings({ autoReconnect: e.target.checked })}
                className="w-5 h-5 rounded accent-emerald-600 cursor-pointer"
              />
            </div>

            {printerSettings.autoReconnect && (
              <div className="grid grid-cols-2 gap-3 text-xs pt-1 border-t border-slate-200/60 dark:border-slate-700">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">
                    Retry Interval: {printerSettings.reconnectInterval}s
                  </label>
                  <input
                    type="range"
                    min="3"
                    max="15"
                    step="1"
                    value={printerSettings.reconnectInterval}
                    onChange={(e) => updatePrinterSettings({ reconnectInterval: Number(e.target.value) })}
                    className="w-full accent-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">
                    Max Attempts: {printerSettings.maxReconnectAttempts}
                  </label>
                  <input
                    type="range"
                    min="3"
                    max="10"
                    step="1"
                    value={printerSettings.maxReconnectAttempts}
                    onChange={(e) => updatePrinterSettings({ maxReconnectAttempts: Number(e.target.value) })}
                    className="w-full accent-emerald-600"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* CARD 2: PAPER SIZE & PRINT HEAD HARDWARE */}
        <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
            <Sliders className="w-4 h-4 text-emerald-600" />
            <span>Thermal Paper Roll & Head Specs</span>
          </h3>

          {/* PAPER SIZE SPECIFICALLY 58mm and 80mm */}
          <div>
            <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-2">
              Thermal Paper Width Specification:
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => updatePrinterSettings({ paperWidth: '58mm' })}
                className={`p-3.5 rounded-xl text-left border transition-all ${
                  printerSettings.paperWidth === '58mm'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-slate-900 dark:text-white shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                }`}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="font-extrabold text-sm">58mm Roll</span>
                  {printerSettings.paperWidth === '58mm' && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  )}
                </div>
                <p className="text-[11px] text-slate-500">
                  384 Dots · 32 columns Font A · Portable standard
                </p>
              </button>

              <button
                type="button"
                onClick={() => updatePrinterSettings({ paperWidth: '80mm' })}
                className={`p-3.5 rounded-xl text-left border transition-all ${
                  printerSettings.paperWidth === '80mm'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-slate-900 dark:text-white shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                }`}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="font-extrabold text-sm">80mm Roll</span>
                  {printerSettings.paperWidth === '80mm' && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  )}
                </div>
                <p className="text-[11px] text-slate-500">
                  576 Dots · 48 columns Font A · Desktop POS standard
                </p>
              </button>
            </div>
          </div>

          {/* Density, Cut & Sound Toggles */}
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700">
              <div>
                <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                  Automatic Paper Cut (GS V)
                </span>
                <span className="text-[11px] text-slate-500">
                  Partial cut at the end of every receipt
                </span>
              </div>
              <input
                type="checkbox"
                checked={printerSettings.autoCut}
                onChange={(e) => updatePrinterSettings({ autoCut: e.target.checked })}
                className="w-5 h-5 rounded accent-emerald-600 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700">
              <div>
                <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                  Acoustic Buzzer & Stepper Sound
                </span>
                <span className="text-[11px] text-slate-500">
                  Piezo buzzer and mechanical motor audio feedback
                </span>
              </div>
              <input
                type="checkbox"
                checked={printerSettings.soundEnabled}
                onChange={(e) => updatePrinterSettings({ soundEnabled: e.target.checked })}
                className="w-5 h-5 rounded accent-emerald-600 cursor-pointer"
              />
            </div>

            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1">
                Paper Feed Margin After Print: ({printerSettings.feedLinesAfterPrint} lines)
              </label>
              <input
                type="range"
                min="1"
                max="6"
                value={printerSettings.feedLinesAfterPrint}
                onChange={(e) => updatePrinterSettings({ feedLinesAfterPrint: Number(e.target.value) })}
                className="w-full accent-emerald-600"
              />
            </div>
          </div>
        </div>

        {/* CARD 3: CUSTOM BUSINESS SETTINGS (Requirement 5) */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
            <Store className="w-4 h-4 text-emerald-600" />
            <span>Custom Business Identity & Receipt Defaults</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                Shop / Merchant Name
              </label>
              <input
                type="text"
                value={businessSettings.shopName}
                onChange={(e) => updateBusinessSettings({ shopName: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
              />
            </div>

            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                Tagline / Slogan
              </label>
              <input
                type="text"
                value={businessSettings.tagline}
                onChange={(e) => updateBusinessSettings({ tagline: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                Cashier / Operator Name
              </label>
              <input
                type="text"
                value={businessSettings.cashierName}
                onChange={(e) => updateBusinessSettings({ cashierName: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                Shop Address
              </label>
              <input
                type="text"
                value={businessSettings.address}
                onChange={(e) => updateBusinessSettings({ address: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                Phone Number
              </label>
              <input
                type="text"
                value={businessSettings.phone}
                onChange={(e) => updateBusinessSettings({ phone: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                Tax / VAT / GST Registration #
              </label>
              <input
                type="text"
                value={businessSettings.taxId}
                onChange={(e) => updateBusinessSettings({ taxId: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                Receipt ID Prefix
              </label>
              <input
                type="text"
                value={businessSettings.receiptIdPrefix}
                onChange={(e) => updateBusinessSettings({ receiptIdPrefix: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                Currency Symbol
              </label>
              <input
                type="text"
                value={businessSettings.currencySymbol}
                onChange={(e) => updateBusinessSettings({ currencySymbol: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-center"
              />
            </div>

            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                Current Sequence Counter
              </label>
              <input
                type="number"
                value={businessSettings.receiptCounter}
                onChange={(e) => updateBusinessSettings({ receiptCounter: Number(e.target.value) })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono"
              />
            </div>
          </div>

          {/* Logo & Footer Message */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
            {/* Logo Settings */}
            <div className="space-y-2">
              <label className="block text-slate-700 dark:text-slate-300 font-bold">
                Business Logo on Receipts:
              </label>
              <div className="flex items-center gap-3">
                <label className="cursor-pointer px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-semibold flex items-center gap-1.5 transition-colors">
                  <Upload className="w-4 h-4 text-emerald-600" />
                  <span>Upload Logo Image</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                </label>

                {/* Preset Icons */}
                <div className="flex items-center gap-1">
                  {(['Store', 'Coffee', 'ShoppingBag', 'Zap'] as const).map((ic) => (
                    <button
                      key={ic}
                      type="button"
                      onClick={() => updateBusinessSettings({ logoType: 'icon', selectedIcon: ic })}
                      className={`w-8 h-8 rounded-lg flex items-center justify-center border transition-all ${
                        businessSettings.logoType === 'icon' && businessSettings.selectedIcon === ic
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-600 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {ic === 'Store' && <Store className="w-4 h-4" />}
                      {ic === 'Coffee' && <Coffee className="w-4 h-4" />}
                      {ic === 'ShoppingBag' && <ShoppingBag className="w-4 h-4" />}
                      {ic === 'Zap' && <Zap className="w-4 h-4" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer Message */}
            <div className="space-y-2">
              <label className="block text-slate-700 dark:text-slate-300 font-bold">
                Custom Footer Message & Policy:
              </label>
              <input
                type="text"
                value={businessSettings.footerMessage}
                onChange={(e) => updateBusinessSettings({ footerMessage: e.target.value })}
                placeholder="Thank you for your business!"
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
