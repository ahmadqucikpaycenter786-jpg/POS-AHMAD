import React from 'react';
import {
  Printer,
  Wifi,
  Bluetooth,
  RotateCcw,
  Sun,
  Moon,
  RefreshCw,
  Sliders,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const AndroidHeader: React.FC = () => {
  const {
    printerSettings,
    togglePaperWidth,
    lastPrintItem,
    quickReprintLast,
    darkMode,
    setDarkMode,
    connectPrinter,
    disconnectPrinter,
    isPrinting,
    setActiveTab,
  } = useApp();

  const isConnected = printerSettings.connectionStatus === 'connected';
  const isConnecting = printerSettings.connectionStatus === 'connecting' || printerSettings.connectionStatus === 'reconnecting';

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      {/* Android Device Status Row */}
      <div className="flex items-center justify-between px-4 py-1 text-[11px] font-mono border-b border-slate-100 dark:border-slate-800/60 text-slate-500 dark:text-slate-400">
        <div className="flex items-center gap-2">
          <span className="font-semibold tracking-wide">POS TERMINAL</span>
          <span>·</span>
          <span>{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        </div>

        <div className="flex items-center gap-3">
          {/* Connection status badge */}
          <button
            onClick={() => {
              if (isConnected) {
                disconnectPrinter();
              } else {
                connectPrinter();
              }
            }}
            title={isConnected ? 'Click to disconnect' : 'Click to connect'}
            className="flex items-center gap-1.5 hover:opacity-80 transition-opacity"
          >
            {printerSettings.connectionType === 'wifi' ? (
              <Wifi className={`w-3.5 h-3.5 ${isConnected ? 'text-emerald-500' : isConnecting ? 'text-amber-500 animate-pulse' : 'text-rose-500'}`} />
            ) : (
              <Bluetooth className={`w-3.5 h-3.5 ${isConnected ? 'text-sky-500' : isConnecting ? 'text-amber-500 animate-pulse' : 'text-rose-500'}`} />
            )}
            <span className={`capitalize font-medium ${isConnected ? 'text-emerald-600 dark:text-emerald-400' : isConnecting ? 'text-amber-600 dark:text-amber-400' : 'text-rose-600 dark:text-rose-400'}`}>
              {printerSettings.connectionStatus}
            </span>
          </button>

          <span>·</span>
          <span>BATT 98%</span>
        </div>
      </div>

      {/* Main Top Bar */}
      <div className="flex items-center justify-between px-4 py-2.5 gap-2">
        {/* Brand Zone */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-slate-900 dark:bg-emerald-600 text-white flex items-center justify-center shadow-sm shrink-0">
            <Printer className="w-5 h-5 text-emerald-400 dark:text-white" />
          </div>
          <div className="min-w-0">
            <h1 className="text-base font-bold tracking-tight text-slate-900 dark:text-white truncate leading-tight">
              ThermalPOS Pro
            </h1>
            <div className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 truncate">
              <span>{printerSettings.connectionType === 'wifi' ? printerSettings.wifiIp : printerSettings.bluetoothDeviceName}</span>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Paper Size Switcher 58mm / 80mm */}
          <button
            onClick={() => togglePaperWidth()}
            aria-label="Toggle paper size"
            className="h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/80 transition-colors flex items-center gap-1 text-xs font-semibold"
            title="Switch paper width between 58mm and 80mm"
          >
            <Sliders className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>{printerSettings.paperWidth}</span>
          </button>

          {/* Quick Reprint Button */}
          <button
            onClick={quickReprintLast}
            disabled={!lastPrintItem || isPrinting}
            aria-label="Quick reprint last receipt"
            className={`h-9 px-2.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
              lastPrintItem && !isPrinting
                ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-sm shadow-amber-500/20 active:scale-95'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
            }`}
            title={lastPrintItem ? `Quick Reprint: ${lastPrintItem.title} (${lastPrintItem.receiptId})` : 'No recent prints'}
          >
            <RotateCcw className={`w-3.5 h-3.5 ${isPrinting ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Reprint</span>
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            aria-label="Toggle theme"
            className="w-9 h-9 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/80 flex items-center justify-center transition-colors"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
          </button>
        </div>
      </div>
    </header>
  );
};
