import React, { useState, useEffect } from 'react';
import {
  X,
  Printer,
  CheckCircle2,
  FileCode,
  Download,
  Volume2,
  Scissors,
  Check,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EscPosBuilder, buildReceiptEscPos } from '../utils/escpos';
import { thermalAudio } from '../utils/audio';

export const PrintModal: React.FC = () => {
  const {
    printModalData,
    closePrintModal,
    printerSettings,
    businessSettings,
  } = useApp();

  const [progress, setProgress] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [showHexDump, setShowHexDump] = useState(false);
  const [hexDump, setHexDump] = useState<string>('');
  const [binaryData, setBinaryData] = useState<Uint8Array | null>(null);

  useEffect(() => {
    if (!printModalData?.isOpen) {
      setProgress(0);
      setIsFinished(false);
      setShowHexDump(false);
      return;
    }

    // Build raw ESC/POS binary packet
    let bytes: Uint8Array;
    if (printModalData.type === 'receipt' && typeof printModalData.content === 'object') {
      bytes = buildReceiptEscPos(printModalData.content, businessSettings, printModalData.paperWidth);
    } else if (printModalData.type === 'ocr_text' && typeof printModalData.content === 'string') {
      const b = new EscPosBuilder();
      b.bold(true).line('--- EXTRACTED RECEIPT TEXT ---').bold(false);
      b.text(printModalData.content);
      b.feed(3);
      b.cut();
      bytes = b.build();
    } else {
      const b = new EscPosBuilder();
      b.line(printModalData.title);
      b.feed(2);
      b.cut();
      bytes = b.build();
    }

    setBinaryData(bytes);
    const hex = Array.from(bytes.slice(0, 160))
      .map((b) => b.toString(16).padStart(2, '0').toUpperCase())
      .join(' ');
    setHexDump(hex + (bytes.length > 160 ? ` ... (+${bytes.length - 160} bytes)` : ''));

    // Animate printing progress simulating thermal print head burning
    setProgress(0);
    setIsFinished(false);

    const startTime = Date.now();
    const duration = 1200; // 1.2s realistic print feed
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(pct);

      if (pct >= 100) {
        clearInterval(interval);
        setIsFinished(true);
        if (printerSettings.soundEnabled) {
          thermalAudio.playSuccessChime();
        }
      }
    }, 40);

    return () => clearInterval(interval);
  }, [printModalData, businessSettings, printerSettings.soundEnabled]);

  const handleDownloadBinary = () => {
    if (!binaryData) return;
    const blob = new Blob([new Uint8Array(binaryData)], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `thermal-print-${Date.now()}.prn`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSystemPrint = () => {
    window.print();
  };

  const handleTestBuzzer = () => {
    thermalAudio.playBuzzer(2400, 0.15);
  };

  if (!printModalData?.isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Printer className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                {isFinished ? 'Print Complete' : 'Printing in Progress...'}
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Target: {printerSettings.connectionType.toUpperCase()} ({printerSettings.paperWidth})
              </p>
            </div>
          </div>

          <button
            onClick={closePrintModal}
            className="w-8 h-8 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4">
          {/* Progress Bar & Status */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-medium text-slate-600 dark:text-slate-300">
              <span className="flex items-center gap-1.5">
                {isFinished ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span>Dispatched to Thermal Print Head</span>
                  </>
                ) : (
                  <>
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                    <span>Feeding & Burning Paper...</span>
                  </>
                )}
              </span>
              <span className="font-mono">{progress}%</span>
            </div>

            <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded-full transition-all duration-75"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {/* Paper Roll Feed Animation Sandbox */}
          <div className="relative bg-slate-100 dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-slate-800/80 text-center overflow-hidden">
            <div className="text-[11px] font-mono text-slate-400 mb-2">
              PAPER EXIT SLOT (THERMAL HEAD ACTIVE)
            </div>

            {/* Simulated Paper Slip Emerging from slot */}
            <div
              className={`mx-auto bg-white text-black p-3 rounded-t-sm shadow-md border-x border-t border-slate-300 font-thermal text-[11px] text-left transition-transform duration-300 ${
                printModalData.paperWidth === '58mm' ? 'w-[200px]' : 'w-[260px]'
              }`}
              style={{
                transform: `translateY(${(100 - progress) * 0.4}px)`,
                opacity: progress > 10 ? 1 : 0.6,
              }}
            >
              <div className="font-bold text-center border-b border-black pb-0.5 mb-1 truncate">
                {businessSettings.shopName}
              </div>
              <div className="text-[9px] flex justify-between">
                <span>{printModalData.title}</span>
                <span>{printModalData.paperWidth}</span>
              </div>
              <div className="my-1 border-t border-dashed border-slate-400" />
              <div className="text-[9px] text-slate-500 text-center">
                {isFinished ? '✓ PRINT SUCCESS' : 'Burning pixels...'}
              </div>
            </div>

            {/* Jagged tear line */}
            <div className="w-48 mx-auto h-1.5 receipt-jagged-bottom mt-1" />
          </div>

          {/* Diagnostics and Hardware Buttons */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={handleTestBuzzer}
              className="py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center gap-1.5 font-medium transition-colors"
            >
              <Volume2 className="w-3.5 h-3.5 text-sky-500" />
              <span>Beep Buzzer</span>
            </button>

            <button
              onClick={() => setShowHexDump(!showHexDump)}
              className="py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center gap-1.5 font-medium transition-colors"
            >
              <FileCode className="w-3.5 h-3.5 text-amber-500" />
              <span>{showHexDump ? 'Hide Hex' : 'ESC/POS Hex'}</span>
            </button>
          </div>

          {/* Hex Dump Drawer */}
          {showHexDump && (
            <div className="p-2.5 rounded-xl bg-slate-900 text-emerald-400 font-mono text-[10px] leading-relaxed max-h-28 overflow-y-auto border border-slate-800 break-all select-all">
              <div className="text-slate-500 mb-1 flex justify-between">
                <span>ESC/POS Command Stream:</span>
                <span>{binaryData?.length} bytes</span>
              </div>
              {hexDump}
            </div>
          )}
        </div>

        {/* Modal Footer Actions */}
        <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
          <button
            onClick={handleDownloadBinary}
            className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 flex items-center gap-1 transition-colors"
            title="Download .prn raw binary file"
          >
            <Download className="w-3.5 h-3.5" />
            <span>.PRN File</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSystemPrint}
              className="px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              title="Open browser print dialog for system-installed thermal printers"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>System Print</span>
            </button>

            <button
              onClick={closePrintModal}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1 shadow-sm transition-all"
            >
              <Check className="w-4 h-4" />
              <span>Done</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
