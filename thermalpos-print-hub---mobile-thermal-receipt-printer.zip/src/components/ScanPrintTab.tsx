import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  Camera,
  Scissors,
  Printer,
  FileText,
  Sparkles,
  Layers,
  Copy,
  Edit3,
  Check,
  AlertCircle,
  Sliders,
  Image as ImageIcon,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CroppingModal } from './CroppingModal';
import { processThermalMonochrome } from '../utils/dithering';
import { extractReceiptText, OcrResult } from '../utils/ocr';
import { ImageProcessingOptions } from '../types';

export const ScanPrintTab: React.FC = () => {
  const {
    printerSettings,
    togglePaperWidth,
    executePrint,
    isPrinting,
    showToast,
  } = useApp();

  const [rawImageSrc, setRawImageSrc] = useState<string | null>(null);
  const [croppedImageSrc, setCroppedImageSrc] = useState<string | null>(null);
  const [isCropModalOpen, setIsCropModalOpen] = useState(false);

  // Active Print Mode: 'bw_image' vs 'ocr_text'
  const [printMode, setPrintMode] = useState<'bw_image' | 'ocr_text'>('bw_image');

  // Dithered bitmap preview
  const [ditheredCanvas, setDitheredCanvas] = useState<HTMLCanvasElement | null>(null);
  const [ditherDataUrl, setDitherDataUrl] = useState<string | null>(null);

  // OCR state
  const [isExtractingOcr, setIsExtractingOcr] = useState(false);
  const [ocrResult, setOcrResult] = useState<OcrResult | null>(null);
  const [editableOcrText, setEditableOcrText] = useState<string>('');

  const [processingOptions, setProcessingOptions] = useState<ImageProcessingOptions>({
    ditherType: 'floyd_steinberg',
    threshold: 128,
    contrast: 15,
    brightness: 0,
    invert: false,
    rotation: 0,
  });

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Sample receipt screenshots for instant 1-tap testing
  const sampleScreenshots = [
    {
      title: 'Payment Receipt Slip',
      url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="384" height="480" viewBox="0 0 384 480"><rect width="384" height="480" fill="%23ffffff"/><text x="192" y="50" font-family="monospace" font-size="18" font-weight="bold" text-anchor="middle" fill="%23000">AHMAD QUICK PAY</text><text x="192" y="80" font-family="monospace" font-size="12" text-anchor="middle" fill="%23333">TRANSACTION CONFIRMATION</text><line x1="20" y1="100" x2="364" y2="100" stroke="%23000" stroke-width="2" stroke-dasharray="4,4"/><text x="30" y="130" font-family="monospace" font-size="13" fill="%23000">TXN ID: TX-9028193</text><text x="30" y="160" font-family="monospace" font-size="13" fill="%23000">DATE: 2026-11-10 14:22</text><text x="30" y="190" font-family="monospace" font-size="13" fill="%23000">PAYEE: Metro Fiber Co.</text><line x1="20" y1="210" x2="364" y2="210" stroke="%23000" stroke-width="1"/><text x="30" y="240" font-family="monospace" font-size="14" fill="%23000">BILL AMOUNT:      $48.00</text><text x="30" y="270" font-family="monospace" font-size="14" fill="%23000">FEE / SURCHARGE:   $2.50</text><line x1="20" y1="290" x2="364" y2="290" stroke="%23000" stroke-width="2"/><text x="30" y="330" font-family="monospace" font-size="18" font-weight="bold" fill="%23000">TOTAL:            $50.50</text><text x="30" y="360" font-family="monospace" font-size="13" fill="%23333">STATUS: SUCCESS / PAID</text><line x1="20" y1="380" x2="364" y2="380" stroke="%23000" stroke-width="1" stroke-dasharray="4,4"/><text x="192" y="420" font-family="monospace" font-size="12" text-anchor="middle" fill="%23666">CUSTOMER COPY - THANK YOU</text></svg>',
    },
    {
      title: 'Cafe & Bistro Order',
      url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="384" height="460" viewBox="0 0 384 460"><rect width="384" height="460" fill="%23ffffff"/><text x="192" y="45" font-family="monospace" font-size="20" font-weight="bold" text-anchor="middle" fill="%23000">CENTRAL CAFE %26 ROAST</text><text x="192" y="70" font-family="monospace" font-size="11" text-anchor="middle" fill="%23555">TABLE #08 - ORDER 449</text><line x1="20" y1="85" x2="364" y2="85" stroke="%23000" stroke-width="1"/><text x="30" y="115" font-family="monospace" font-size="13" fill="%23000">1x Double Espresso  $4.50</text><text x="30" y="145" font-family="monospace" font-size="13" fill="%23000">1x Almond Croissant $5.00</text><text x="30" y="175" font-family="monospace" font-size="13" fill="%23000">1x Sparkling Water  $3.00</text><line x1="20" y1="195" x2="364" y2="195" stroke="%23000" stroke-width="1" stroke-dasharray="3,3"/><text x="30" y="225" font-family="monospace" font-size="13" fill="%23000">SUBTOTAL:          $12.50</text><text x="30" y="250" font-family="monospace" font-size="13" fill="%23000">SERVICE FEE (10%):  $1.25</text><text x="30" y="275" font-family="monospace" font-size="13" fill="%23000">SALES TAX:          $1.00</text><line x1="20" y1="295" x2="364" y2="295" stroke="%23000" stroke-width="2"/><text x="30" y="335" font-family="monospace" font-size="17" font-weight="bold" fill="%23000">AMOUNT PAID:       $14.75</text><text x="192" y="390" font-family="monospace" font-size="12" text-anchor="middle" fill="%23444">HAVE A WONDERFUL DAY!</text></svg>',
    },
  ];

  // Handle image load from file picker
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const src = event.target?.result as string;
      setRawImageSrc(src);
      // Immediately open the cropping window as requested!
      setIsCropModalOpen(true);
      showToast('Image loaded. Crop window opened.', 'info');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Handle clipboard paste
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const blob = items[i].getAsFile();
          if (blob) {
            const reader = new FileReader();
            reader.onload = (event) => {
              const src = event.target?.result as string;
              setRawImageSrc(src);
              setIsCropModalOpen(true);
              showToast('Screenshot pasted from clipboard! Crop window opened.', 'info');
            };
            reader.readAsDataURL(blob);
            break;
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [showToast]);

  // When crop is confirmed
  const handleConfirmCrop = (croppedUrl: string, opts: ImageProcessingOptions) => {
    setCroppedImageSrc(croppedUrl);
    setProcessingOptions(opts);
    setIsCropModalOpen(false);

    // Process monochrome bitmap
    const img = new Image();
    img.onload = () => {
      const processed = processThermalMonochrome(
        img,
        img.width,
        img.height,
        printerSettings.paperWidth,
        opts
      );
      setDitheredCanvas(processed.canvas);
      setDitherDataUrl(processed.dataUrl);
    };
    img.src = croppedUrl;

    showToast('Crop applied successfully', 'success');
  };

  // Direct B&W print from modal or tab
  const handleDirectBwPrint = (bitmapCanvas: HTMLCanvasElement, opts: ImageProcessingOptions) => {
    setIsCropModalOpen(false);
    executePrint(
      'B&W Thermal Image Print',
      'bw_image',
      bitmapCanvas.toDataURL('image/png')
    );
  };

  // OCR Extraction Trigger
  const handleExtractOcr = async (imageUrl: string) => {
    setIsCropModalOpen(false);
    setPrintMode('ocr_text');
    setIsExtractingOcr(true);
    showToast('Extracting receipt text via OCR...', 'info');

    try {
      const result = await extractReceiptText(imageUrl);
      setOcrResult(result);
      setEditableOcrText(result.rawText);
      showToast('Receipt text extracted successfully!', 'success');
    } catch {
      showToast('OCR extraction failed. Please check image clarity.', 'error');
    } finally {
      setIsExtractingOcr(false);
    }
  };

  // Print OCR Extracted Text
  const handlePrintOcrText = () => {
    if (!editableOcrText.trim()) {
      showToast('No text available to print', 'error');
      return;
    }
    executePrint(
      'OCR Extracted Receipt Text',
      'ocr_text',
      editableOcrText
    );
  };

  return (
    <div className="max-w-6xl mx-auto pb-24 px-3 sm:px-4 pt-3 space-y-6">
      {/* Hidden file & camera inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileSelect}
        className="hidden"
      />

      {/* Header card */}
      <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sky-500/10 text-sky-600 dark:text-sky-400 flex items-center justify-center">
            <ImageIcon className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Gallery / Screenshot Crop & Print
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Share or upload receipt screenshots. Crop precisely & print via B&W or OCR.
            </p>
          </div>
        </div>

        {/* Upload Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="h-9 px-3.5 rounded-xl bg-slate-900 dark:bg-emerald-600 hover:bg-slate-800 dark:hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
          >
            <Upload className="w-4 h-4" />
            <span>Open Gallery</span>
          </button>

          <button
            onClick={() => cameraInputRef.current?.click()}
            className="h-9 px-3.5 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-all"
          >
            <Camera className="w-4 h-4" />
            <span>Camera</span>
          </button>
        </div>
      </div>

      {/* Sample Receipt Screenshots Banner */}
      {!croppedImageSrc && (
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Or Test Instantly with Sample Screenshots:
            </span>
            <span className="text-slate-400">Click to load & crop</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {sampleScreenshots.map((sample, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setRawImageSrc(sample.url);
                  setIsCropModalOpen(true);
                  showToast(`Loaded ${sample.title}. Crop window open!`, 'info');
                }}
                className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-emerald-500 dark:hover:border-emerald-500 text-left transition-all flex items-center gap-3 group"
              >
                <div className="w-12 h-14 bg-slate-100 dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-700 flex items-center justify-center overflow-hidden shrink-0">
                  <img src={sample.url} alt={sample.title} className="w-full h-full object-cover" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-emerald-600 transition-colors">
                    {sample.title}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Pre-rendered POS receipt with fee, line items, and total
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* TWO DISTINCT PRINTING MODES TABS */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-200/70 dark:bg-slate-800/80 rounded-2xl max-w-md">
        <button
          onClick={() => setPrintMode('bw_image')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            printMode === 'bw_image'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Layers className="w-4 h-4 text-emerald-600" />
          <span>Mode 1: Direct B&W Image</span>
        </button>

        <button
          onClick={() => {
            setPrintMode('ocr_text');
            if (croppedImageSrc && !ocrResult) {
              handleExtractOcr(croppedImageSrc);
            }
          }}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            printMode === 'ocr_text'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <FileText className="w-4 h-4 text-sky-600" />
          <span>Mode 2: OCR Extracted Text</span>
        </button>
      </div>

      {/* Main Workspace based on Print Mode */}
      {printMode === 'bw_image' ? (
        /* MODE 1: DIRECT B&W IMAGE PRINTING */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Controls & Adjustment Column */}
          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Monochrome Print Configuration
                </h3>
                {croppedImageSrc && (
                  <button
                    onClick={() => setIsCropModalOpen(true)}
                    className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold flex items-center gap-1"
                  >
                    <Scissors className="w-3.5 h-3.5" />
                    <span>Re-Crop Image</span>
                  </button>
                )}
              </div>

              {/* Status & Options */}
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1 font-medium">
                    Paper Print Head Width:
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => togglePaperWidth('58mm')}
                      className={`py-2 px-3 rounded-xl font-bold border transition-all ${
                        printerSettings.paperWidth === '58mm'
                          ? 'bg-slate-900 text-white dark:bg-emerald-600 border-transparent'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      58mm (384 px)
                    </button>
                    <button
                      onClick={() => togglePaperWidth('80mm')}
                      className={`py-2 px-3 rounded-xl font-bold border transition-all ${
                        printerSettings.paperWidth === '80mm'
                          ? 'bg-slate-900 text-white dark:bg-emerald-600 border-transparent'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      80mm (576 px)
                    </button>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
                  <div className="flex justify-between items-center text-slate-600 dark:text-slate-400">
                    <span>Algorithm:</span>
                    <span className="font-semibold text-slate-900 dark:text-white capitalize">
                      {processingOptions.ditherType.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-slate-600 dark:text-slate-400">
                    <span>Monochrome Density:</span>
                    <span className="font-semibold text-slate-900 dark:text-white">
                      1-Bit Pure Black/White
                    </span>
                  </div>
                </div>

                {/* Print CTA */}
                <button
                  onClick={() => {
                    if (ditheredCanvas) {
                      handleDirectBwPrint(ditheredCanvas, processingOptions);
                    } else if (croppedImageSrc) {
                      const img = new Image();
                      img.onload = () => {
                        const processed = processThermalMonochrome(
                          img,
                          img.width,
                          img.height,
                          printerSettings.paperWidth,
                          processingOptions
                        );
                        handleDirectBwPrint(processed.canvas, processingOptions);
                      };
                      img.src = croppedImageSrc;
                    } else {
                      showToast('Please upload or select an image first', 'info');
                    }
                  }}
                  disabled={isPrinting || (!croppedImageSrc && !rawImageSrc)}
                  className="w-full h-12 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-200 dark:disabled:bg-slate-800 disabled:text-slate-400 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.98]"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print B&W Image on {printerSettings.paperWidth} Roll</span>
                </button>
              </div>
            </div>
          </div>

          {/* Dithered Paper Head Preview Column */}
          <div className="lg:col-span-6 space-y-3">
            <div className="bg-slate-200 dark:bg-slate-950 p-4 sm:p-6 rounded-3xl border border-slate-300 dark:border-slate-800 flex flex-col items-center min-h-[380px] justify-center">
              <div className="w-full flex items-center justify-between text-xs text-slate-500 font-mono mb-3 px-1">
                <span>DITHERED THERMAL PREVIEW</span>
                <span>{printerSettings.paperWidth}</span>
              </div>

              {ditherDataUrl || croppedImageSrc ? (
                <div
                  className={`bg-white p-3 rounded-sm shadow-xl border-x border-slate-300 relative select-none ${
                    printerSettings.paperWidth === '58mm' ? 'max-w-[280px]' : 'max-w-[360px]'
                  }`}
                >
                  <div className="h-1.5 -mx-3 -mt-3 receipt-jagged-top mb-2" />
                  <img
                    src={ditherDataUrl || croppedImageSrc || ''}
                    alt="Thermal Dithered Print"
                    className="pixelated w-full h-auto object-contain block border border-slate-200"
                  />
                  <div className="mt-2 text-center text-[10px] font-mono text-slate-500">
                    -- END OF RECEIPT --
                  </div>
                  <div className="h-2 -mx-3 -mb-3 receipt-jagged-bottom mt-2" />
                </div>
              ) : (
                <div className="text-center p-8 text-slate-400 space-y-2">
                  <ImageIcon className="w-10 h-10 mx-auto opacity-40" />
                  <p className="text-xs font-medium">No image loaded</p>
                  <p className="text-[11px] text-slate-500">
                    Upload an image or tap a sample above to adjust and print.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* MODE 2: OCR TEXT EXTRACTION TO PRINT ONLY EXTRACTED TEXT */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-sky-600" />
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Extracted Receipt Text
                  </h3>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      if (croppedImageSrc) handleExtractOcr(croppedImageSrc);
                      else if (rawImageSrc) handleExtractOcr(rawImageSrc);
                      else showToast('Please select or upload an image first', 'info');
                    }}
                    disabled={isExtractingOcr}
                    className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 hover:bg-sky-100 flex items-center gap-1 transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{isExtractingOcr ? 'Scanning...' : 'Re-Run OCR'}</span>
                  </button>
                </div>
              </div>

              {/* Editable Text Area for Clean ESC/POS Printing */}
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">
                  Review & edit text before printing on {printerSettings.paperWidth} thermal roll:
                </label>
                <textarea
                  rows={13}
                  value={editableOcrText}
                  onChange={(e) => setEditableOcrText(e.target.value)}
                  placeholder="Extracted text will appear here. You can also paste or type receipt text directly..."
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-xs text-slate-900 dark:text-slate-100 focus:outline-emerald-500 leading-relaxed"
                />
              </div>

              {/* Extracted Fields Summary */}
              {ocrResult && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300">
                  <div>
                    <span className="text-slate-400 block">Merchant:</span>
                    <span className="font-semibold truncate block">{ocrResult.merchantName || 'Detected'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Date:</span>
                    <span className="font-semibold">{ocrResult.date || 'Today'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Fee / Surcharge:</span>
                    <span className="font-semibold">{ocrResult.fee ? `$${ocrResult.fee}` : 'None'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Total:</span>
                    <span className="font-bold text-slate-900 dark:text-white">
                      {ocrResult.total ? `$${ocrResult.total}` : 'Extracted'}
                    </span>
                  </div>
                </div>
              )}

              {/* Print Extracted Text Button */}
              <button
                onClick={handlePrintOcrText}
                disabled={isPrinting || !editableOcrText.trim()}
                className="w-full h-12 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:bg-slate-200 dark:disabled:bg-slate-800 disabled:text-slate-400 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.98]"
              >
                <Printer className="w-4 h-4" />
                <span>Print Extracted Text Only</span>
              </button>
            </div>
          </div>

          {/* Right Column: OCR Text Paper Simulation */}
          <div className="lg:col-span-5 space-y-3">
            <div className="bg-slate-200 dark:bg-slate-950 p-4 sm:p-6 rounded-3xl border border-slate-300 dark:border-slate-800 flex flex-col items-center">
              <div className="w-full flex items-center justify-between text-xs text-slate-500 font-mono mb-3 px-1">
                <span>TEXT ROLL SIMULATION</span>
                <span>{printerSettings.paperWidth}</span>
              </div>

              <div
                className={`bg-white text-black p-4 rounded-sm shadow-xl border-x border-slate-300 font-thermal text-xs select-text ${
                  printerSettings.paperWidth === '58mm' ? 'w-full max-w-[280px]' : 'w-full max-w-[360px]'
                }`}
              >
                <div className="h-1.5 -mx-4 -mt-4 receipt-jagged-top mb-3" />
                <div className="text-center font-bold pb-2 border-b border-black text-xs">
                  --- OCR EXTRACTED TEXT ---
                </div>
                <pre className="whitespace-pre-wrap font-thermal text-[11px] leading-snug py-2 break-words">
                  {editableOcrText || 'Extracted text preview will show here...'}
                </pre>
                <div className="pt-2 border-t border-dashed border-black text-center text-[10px] text-neutral-600">
                  *** TEXT PRINT FINISHED ***
                </div>
                <div className="h-2 -mx-4 -mb-4 receipt-jagged-bottom mt-3" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cropping Modal Trigger */}
      {rawImageSrc && (
        <CroppingModal
          isOpen={isCropModalOpen}
          imageSrc={rawImageSrc}
          paperWidth={printerSettings.paperWidth}
          onClose={() => setIsCropModalOpen(false)}
          onConfirmCrop={handleConfirmCrop}
          onDirectBwPrint={(canvas, opts) => handleDirectBwPrint(canvas, opts)}
          onExtractOcr={(croppedUrl) => handleExtractOcr(croppedUrl)}
        />
      )}
    </div>
  );
};
