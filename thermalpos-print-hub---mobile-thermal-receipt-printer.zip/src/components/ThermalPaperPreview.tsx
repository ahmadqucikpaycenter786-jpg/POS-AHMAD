import React, { useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import JsBarcode from 'jsbarcode';
import {
  Store,
  Coffee,
  ShoppingBag,
  Zap,
  CheckCircle2,
  Receipt as ReceiptIcon,
} from 'lucide-react';
import { PaperWidth, ReceiptData, BusinessSettings } from '../types';

interface ThermalPaperPreviewProps {
  receipt: ReceiptData;
  business: BusinessSettings;
  paperWidth: PaperWidth;
  isReprint?: boolean;
}

export const ThermalPaperPreview: React.FC<ThermalPaperPreviewProps> = ({
  receipt,
  business,
  paperWidth,
  isReprint,
}) => {
  const qrCanvasRef = useRef<HTMLCanvasElement>(null);
  const barcodeCanvasRef = useRef<HTMLCanvasElement>(null);

  // Render QR Code at the bottom if enabled
  useEffect(() => {
    if (business.showQrAtBottom && qrCanvasRef.current) {
      const qrData = `${business.qrBottomContent || 'https://thermalpos.app/verify/'}${receipt.id}`;
      QRCode.toCanvas(
        qrCanvasRef.current,
        qrData,
        {
          width: paperWidth === '58mm' ? 104 : 124,
          margin: 1,
          color: { dark: '#000000', light: '#ffffff' },
          errorCorrectionLevel: 'M',
        },
        (error) => {
          if (error) console.error('QR Render error', error);
        }
      );
    }
  }, [business.showQrAtBottom, business.qrBottomContent, receipt.id, paperWidth]);

  // Render Barcode for Receipt ID
  useEffect(() => {
    if (barcodeCanvasRef.current && receipt.id) {
      try {
        JsBarcode(barcodeCanvasRef.current, receipt.id, {
          format: 'CODE128',
          width: paperWidth === '58mm' ? 1.4 : 1.8,
          height: 38,
          displayValue: true,
          font: 'JetBrains Mono',
          fontSize: 10,
          margin: 4,
          lineColor: '#000000',
          background: '#ffffff',
        });
      } catch (e) {
        console.error('Barcode error', e);
      }
    }
  }, [receipt.id, paperWidth]);

  // Max characters per line for thermal monospace alignment
  const maxChars = paperWidth === '58mm' ? 32 : 48;
  const dividerDash = '-'.repeat(maxChars);
  const dividerEqual = '='.repeat(maxChars);

  return (
    <div
      className={`mx-auto transition-all duration-300 ${
        paperWidth === '58mm' ? 'w-full max-w-[320px]' : 'w-full max-w-[420px]'
      }`}
    >
      {/* Paper Roll Wrapper with authentic jagged thermal paper tear edge */}
      <div
        id="printable-thermal-receipt"
        className="bg-white text-black p-4 sm:p-5 rounded-sm shadow-xl border-x border-slate-200 select-text relative font-thermal text-xs tracking-tight leading-relaxed overflow-hidden"
      >
        {/* Top jagged cut edge effect */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-b from-slate-200/40 to-transparent" />

        {/* Reprint Watermark Banner */}
        {(receipt.isReprint || isReprint) && (
          <div className="mb-2 py-1 px-2 border-2 border-dashed border-black text-center font-bold text-xs uppercase tracking-wider bg-slate-100">
            *** DUPLICATE / REPRINT ***
          </div>
        )}

        {/* Business Header & Logo */}
        <div className="text-center space-y-1 mb-2">
          {business.logoType === 'custom' && business.logoUrl ? (
            <img
              src={business.logoUrl}
              alt="Shop Logo"
              className="max-h-12 max-w-[140px] mx-auto object-contain mb-1 filter grayscale contrast-200"
            />
          ) : business.logoType === 'icon' ? (
            <div className="w-9 h-9 mx-auto rounded-full border-2 border-black flex items-center justify-center mb-1">
              {business.selectedIcon === 'Coffee' ? (
                <Coffee className="w-5 h-5 text-black" />
              ) : business.selectedIcon === 'ShoppingBag' ? (
                <ShoppingBag className="w-5 h-5 text-black" />
              ) : business.selectedIcon === 'Zap' ? (
                <Zap className="w-5 h-5 text-black" />
              ) : (
                <Store className="w-5 h-5 text-black" />
              )}
            </div>
          ) : null}

          <h2 className="text-sm sm:text-base font-extrabold uppercase tracking-wide leading-tight">
            {business.shopName || 'MY BUSINESS'}
          </h2>

          {business.tagline && (
            <p className="text-[11px] text-neutral-800">{business.tagline}</p>
          )}

          {business.address && (
            <p className="text-[10px] text-neutral-700 leading-normal">{business.address}</p>
          )}

          <div className="text-[10px] text-neutral-700 flex flex-wrap justify-center gap-x-2">
            {business.phone && <span>Tel: {business.phone}</span>}
            {business.taxId && <span>Tax ID: {business.taxId}</span>}
          </div>
        </div>

        {/* Receipt Meta (ID, Date, Time, Cashier) */}
        <div className="text-[11px] py-1 border-t border-b border-black border-dashed space-y-0.5">
          <div className="flex justify-between items-center">
            <span className="font-bold">RCPT #: {receipt.id}</span>
            <span>{receipt.date}</span>
          </div>
          <div className="flex justify-between items-center text-[10px]">
            <span>Time: {receipt.time}</span>
            <span>Cashier: {business.cashierName || 'Admin'}</span>
          </div>
          {receipt.customerName && (
            <div className="text-[10px] text-neutral-800 pt-0.5">
              Cust: {receipt.customerName} {receipt.customerPhone ? `(${receipt.customerPhone})` : ''}
            </div>
          )}
        </div>

        {/* Line Items Table */}
        <div className="my-2">
          {paperWidth === '58mm' ? (
            /* 58mm Compact Two-Line View */
            <div className="space-y-1.5 text-[11px]">
              <div className="flex justify-between font-bold border-b border-black pb-0.5">
                <span>ITEM / QTY</span>
                <span>TOTAL</span>
              </div>
              {receipt.items.length === 0 ? (
                <div className="text-center py-2 text-neutral-500 italic text-[10px]">
                  No items in receipt. Add items below.
                </div>
              ) : (
                receipt.items.map((item) => (
                  <div key={item.id} className="leading-tight">
                    <div className="font-semibold text-black break-words">{item.name}</div>
                    <div className="flex justify-between text-[10px] text-neutral-700">
                      <span>
                        {item.quantity} x {business.currencySymbol}{item.unitPrice.toFixed(2)}
                      </span>
                      <span className="font-bold text-black font-mono">
                        {business.currencySymbol}{item.total.toFixed(2)}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          ) : (
            /* 80mm Full 4-Column Table */
            <div className="text-[11px]">
              <div className="grid grid-cols-12 font-bold border-b border-black pb-0.5 text-[10px]">
                <span className="col-span-6">ITEM</span>
                <span className="col-span-2 text-center">QTY</span>
                <span className="col-span-2 text-right">PRICE</span>
                <span className="col-span-2 text-right">TOTAL</span>
              </div>
              {receipt.items.length === 0 ? (
                <div className="text-center py-2 text-neutral-500 italic text-[10px]">
                  No items in receipt. Add items below.
                </div>
              ) : (
                receipt.items.map((item) => (
                  <div key={item.id} className="grid grid-cols-12 py-0.5 text-[10px] border-b border-neutral-200/60">
                    <span className="col-span-6 font-semibold truncate pr-1">{item.name}</span>
                    <span className="col-span-2 text-center">{item.quantity}</span>
                    <span className="col-span-2 text-right font-mono">
                      {business.currencySymbol}{item.unitPrice.toFixed(2)}
                    </span>
                    <span className="col-span-2 text-right font-bold font-mono">
                      {business.currencySymbol}{item.total.toFixed(2)}
                    </span>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Financial Breakdown & DEDICATED FEE FIELD */}
        <div className="border-t border-black border-dashed pt-1.5 space-y-1 text-[11px]">
          <div className="flex justify-between">
            <span>Subtotal:</span>
            <span className="font-mono">{business.currencySymbol}{receipt.subtotal.toFixed(2)}</span>
          </div>

          {receipt.taxAmount > 0 && (
            <div className="flex justify-between text-[10px] text-neutral-800">
              <span>Tax ({receipt.taxPercent}%):</span>
              <span className="font-mono">+{business.currencySymbol}{receipt.taxAmount.toFixed(2)}</span>
            </div>
          )}

          {receipt.discountAmount > 0 && (
            <div className="flex justify-between text-[10px] text-neutral-800">
              <span>Discount:</span>
              <span className="font-mono">-{business.currencySymbol}{receipt.discountAmount.toFixed(2)}</span>
            </div>
          )}

          {/* DEDICATED FEE / AMOUNT RECEIVED FROM CUSTOMER */}
          {receipt.fee > 0 && (
            <div className="flex justify-between font-semibold text-black bg-neutral-100 px-1 py-0.5 rounded">
              <span>{receipt.feeLabel || 'Service / Custom Fee'}:</span>
              <span className="font-mono font-bold">+{business.currencySymbol}{receipt.fee.toFixed(2)}</span>
            </div>
          )}

          {/* Grand Total */}
          <div className="flex justify-between items-baseline pt-1 border-t-2 border-black font-extrabold text-sm sm:text-base">
            <span>TOTAL:</span>
            <span className="font-mono text-base sm:text-lg">
              {business.currencySymbol}{receipt.total.toFixed(2)}
            </span>
          </div>

          {/* Payment & Change breakdown */}
          <div className="pt-1 border-t border-black border-dotted space-y-0.5 text-[10px]">
            <div className="flex justify-between">
              <span>Paid ({receipt.paymentMethod}):</span>
              <span className="font-mono">{business.currencySymbol}{receipt.amountPaid.toFixed(2)}</span>
            </div>
            {receipt.changeDue > 0 && (
              <div className="flex justify-between font-bold">
                <span>Change Due:</span>
                <span className="font-mono">{business.currencySymbol}{receipt.changeDue.toFixed(2)}</span>
              </div>
            )}
          </div>
        </div>

        {/* Barcode representation of Receipt ID */}
        <div className="my-2.5 text-center flex flex-col items-center justify-center">
          <canvas ref={barcodeCanvasRef} className="max-w-full" />
        </div>

        {/* QR Code if enabled */}
        {business.showQrAtBottom && (
          <div className="my-2 flex flex-col items-center justify-center text-center">
            <canvas ref={qrCanvasRef} className="border border-neutral-300 p-1 bg-white" />
            <span className="text-[9px] text-neutral-600 mt-0.5 font-mono">Scan to Verify Receipt</span>
          </div>
        )}

        {/* Footer Notes & Policy */}
        <div className="text-center text-[10px] space-y-1 text-neutral-700 pt-1 border-t border-black border-dashed">
          {business.footerMessage && (
            <p className="font-semibold text-black">{business.footerMessage}</p>
          )}
          {business.disclaimer && (
            <p className="text-[9px] leading-tight text-neutral-600">{business.disclaimer}</p>
          )}
          {receipt.notes && (
            <p className="text-[9px] italic text-neutral-800 bg-neutral-50 p-1 border border-neutral-200">
              Note: {receipt.notes}
            </p>
          )}
          <div className="text-[9px] tracking-widest uppercase pt-1 text-neutral-500">
            *** THANK YOU ***
          </div>
        </div>

        {/* Bottom jagged tear cut edge */}
        <div className="mt-3 -mx-5 h-3 receipt-jagged-bottom" />
      </div>
    </div>
  );
};
