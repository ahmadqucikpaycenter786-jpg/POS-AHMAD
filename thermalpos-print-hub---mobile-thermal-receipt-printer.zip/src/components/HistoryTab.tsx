import React, { useState } from 'react';
import {
  History,
  RotateCcw,
  Search,
  Trash2,
  Printer,
  Download,
  Calendar,
  Layers,
  FileText,
  QrCode,
  DollarSign,
  CheckCircle2,
  Clock,
  Filter,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PrintHistoryItem } from '../types';

export const HistoryTab: React.FC = () => {
  const {
    printHistory,
    lastPrintItem,
    quickReprintLast,
    reprintHistoryItem,
    deleteHistoryItem,
    clearHistory,
    isPrinting,
    businessSettings,
    showToast,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [selectedItemForView, setSelectedItemForView] = useState<PrintHistoryItem | null>(null);

  // Filter history
  const filteredHistory = printHistory.filter((item) => {
    const matchesQuery =
      item.receiptId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterType === 'all' || item.type === filterType;
    return matchesQuery && matchesFilter;
  });

  const totalPrintedAmount = printHistory.reduce((sum, it) => sum + (it.amount || 0), 0);

  const exportHistoryCsv = () => {
    if (printHistory.length === 0) {
      showToast('No history records to export', 'info');
      return;
    }
    const headers = ['ID', 'Date/Time', 'Receipt ID', 'Title', 'Type', 'Paper Width', 'Connection', 'Amount', 'Reprint Count'];
    const rows = printHistory.map((it) => [
      it.id,
      new Date(it.timestamp).toLocaleString(),
      it.receiptId,
      `"${it.title.replace(/"/g, '""')}"`,
      it.type,
      it.paperWidth,
      it.connection,
      it.amount ? it.amount.toFixed(2) : '0.00',
      it.reprintCount || 0,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `thermal-print-history-${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Print history exported as CSV', 'success');
  };

  return (
    <div className="max-w-6xl mx-auto pb-24 px-3 sm:px-4 pt-3 space-y-6">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
            <History className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Print History & Log
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Track recent thermal prints, quick reprint any receipt, and audit customer fees.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={exportHistoryCsv}
            className="h-9 px-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          {printHistory.length > 0 && (
            <button
              onClick={() => {
                if (window.confirm('Are you sure you want to clear all print history?')) {
                  clearHistory();
                }
              }}
              className="h-9 px-3 rounded-xl border border-rose-200 dark:border-rose-900/50 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-semibold text-rose-600 dark:text-rose-400 flex items-center gap-1.5 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Log</span>
            </button>
          )}
        </div>
      </div>

      {/* QUICK REPRINT FEATURE HERO CARD */}
      {lastPrintItem ? (
        <div className="bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-500/30 dark:border-amber-500/20 p-4 sm:p-5 rounded-2xl flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-md shadow-amber-500/20">
              <RotateCcw className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                  Last Printed Item
                </span>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold border border-amber-300/40">
                  {lastPrintItem.receiptId}
                </span>
              </div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white mt-0.5">
                {lastPrintItem.title}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5">
                <span>{new Date(lastPrintItem.timestamp).toLocaleTimeString()}</span>
                <span>·</span>
                <span>{lastPrintItem.paperWidth} roll</span>
                <span>·</span>
                <span>Reprinted: {lastPrintItem.reprintCount || 0} times</span>
              </p>
            </div>
          </div>

          <button
            onClick={quickReprintLast}
            disabled={isPrinting}
            className="h-11 px-5 rounded-xl bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md shadow-amber-500/30 transition-all shrink-0"
          >
            <Printer className="w-4 h-4" />
            <span>Quick Reprint Last Receipt</span>
          </button>
        </div>
      ) : (
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500">
          No receipts printed yet. Print your first bill from the Receipts or Scan tab to enable 1-touch Quick Reprint!
        </div>
      )}

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800">
          <span className="text-slate-500 block mb-1">Total Print Jobs</span>
          <span className="text-xl font-bold font-mono text-slate-900 dark:text-white">
            {printHistory.length}
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800">
          <span className="text-slate-500 block mb-1">Total Transaction Volume</span>
          <span className="text-xl font-bold font-mono text-emerald-600 dark:text-emerald-400">
            {businessSettings.currencySymbol}{totalPrintedAmount.toFixed(2)}
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800">
          <span className="text-slate-500 block mb-1">Receipt Prints</span>
          <span className="text-xl font-bold font-mono text-slate-900 dark:text-white">
            {printHistory.filter((i) => i.type === 'receipt').length}
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800">
          <span className="text-slate-500 block mb-1">Image / OCR / Codes</span>
          <span className="text-xl font-bold font-mono text-slate-900 dark:text-white">
            {printHistory.filter((i) => i.type !== 'receipt').length}
          </span>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Receipt ID or title..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-emerald-500"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1 overflow-x-auto text-xs">
          {[
            { id: 'all', label: 'All Jobs' },
            { id: 'receipt', label: 'Receipts' },
            { id: 'bw_image', label: 'B&W Image' },
            { id: 'ocr_text', label: 'OCR Text' },
            { id: 'barcode_qr', label: 'Codes' },
          ].map((flt) => (
            <button
              key={flt.id}
              onClick={() => setFilterType(flt.id)}
              className={`px-2.5 py-1 rounded-lg font-medium transition-colors whitespace-nowrap ${
                filterType === flt.id
                  ? 'bg-slate-900 text-white dark:bg-emerald-600 font-semibold shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {flt.label}
            </button>
          ))}
        </div>
      </div>

      {/* History Log Table / Cards */}
      <div className="space-y-2">
        {filteredHistory.length === 0 ? (
          <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400 space-y-2">
            <Clock className="w-8 h-8 mx-auto opacity-40" />
            <p className="text-xs font-semibold">No print history matching filters</p>
          </div>
        ) : (
          filteredHistory.map((item) => (
            <div
              key={item.id}
              className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-3 hover:border-slate-300 dark:hover:border-slate-700 transition-all text-xs"
            >
              {/* Item Info */}
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    item.type === 'receipt'
                      ? 'bg-emerald-500/10 text-emerald-600'
                      : item.type === 'bw_image'
                      ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      : item.type === 'ocr_text'
                      ? 'bg-sky-500/10 text-sky-600'
                      : 'bg-purple-500/10 text-purple-600'
                  }`}
                >
                  {item.type === 'receipt' && <DollarSign className="w-5 h-5" />}
                  {item.type === 'bw_image' && <Layers className="w-5 h-5" />}
                  {item.type === 'ocr_text' && <FileText className="w-5 h-5" />}
                  {item.type === 'barcode_qr' && <QrCode className="w-5 h-5" />}
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-slate-900 dark:text-white">
                      {item.receiptId}
                    </span>
                    <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                      {item.type.replace('_', ' ')}
                    </span>
                    {item.reprintCount > 0 && (
                      <span className="text-[10px] font-semibold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-1 rounded">
                        Reprinted ×{item.reprintCount}
                      </span>
                    )}
                  </div>
                  <p className="font-medium text-slate-700 dark:text-slate-300 truncate mt-0.5">
                    {item.title}
                  </p>
                  <p className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                    <span>{new Date(item.timestamp).toLocaleString()}</span>
                    <span>·</span>
                    <span className="font-mono">{item.paperWidth} roll</span>
                    <span>·</span>
                    <span className="capitalize">{item.connection}</span>
                  </p>
                </div>
              </div>

              {/* Amount & Actions */}
              <div className="flex items-center gap-3 shrink-0">
                {item.amount !== undefined && item.amount > 0 && (
                  <div className="text-right">
                    <span className="font-mono text-sm font-bold text-emerald-600 dark:text-emerald-400 block">
                      {businessSettings.currencySymbol}{item.amount.toFixed(2)}
                    </span>
                  </div>
                )}

                {/* Reprint Button */}
                <button
                  onClick={() => reprintHistoryItem(item)}
                  disabled={isPrinting}
                  className="h-8 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold flex items-center gap-1 transition-colors"
                  title="Reprint this receipt"
                >
                  <Printer className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Reprint</span>
                </button>

                {/* Delete Record */}
                <button
                  onClick={() => deleteHistoryItem(item.id)}
                  className="w-8 h-8 rounded-xl text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center justify-center transition-colors"
                  title="Delete from log"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
