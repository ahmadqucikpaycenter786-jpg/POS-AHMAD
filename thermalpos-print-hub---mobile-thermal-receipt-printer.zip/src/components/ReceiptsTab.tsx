import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  Printer,
  RotateCcw,
  RefreshCw,
  Sliders,
  DollarSign,
  User,
  CreditCard,
  Banknote,
  Smartphone,
  Tag,
  Receipt,
  Layers,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ThermalPaperPreview } from './ThermalPaperPreview';
import { ReceiptData } from '../types';

export const ReceiptsTab: React.FC = () => {
  const {
    activeReceipt,
    updateActiveReceipt,
    addItemToReceipt,
    removeItemFromReceipt,
    updateReceiptItem,
    resetReceipt,
    generateNewReceiptId,
    businessSettings,
    printerSettings,
    togglePaperWidth,
    executePrint,
    isPrinting,
  } = useApp();

  const [newItemName, setNewItemName] = useState('');
  const [newItemPrice, setNewItemPrice] = useState('');
  const [newItemQty, setNewItemQty] = useState('1');

  // Quick Preset Items common in QuickPay / POS centers
  const quickPresets = [
    { name: 'Mobile Recharge (25GB)', price: 15.00 },
    { name: 'Utility Bill Payment', price: 45.00 },
    { name: 'Money Transfer Service', price: 100.00 },
    { name: 'Document Photocopy (x5)', price: 2.50 },
    { name: 'Thermal Roll 58/80mm', price: 3.50 },
    { name: 'Payment Processing', price: 5.00 },
  ];

  const handleAddNewItem = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newItemName.trim()) return;

    const price = parseFloat(newItemPrice) || 0;
    const qty = parseInt(newItemQty, 10) || 1;

    addItemToReceipt({
      name: newItemName.trim(),
      unitPrice: price,
      quantity: Math.max(1, qty),
    });

    setNewItemName('');
    setNewItemPrice('');
    setNewItemQty('1');
  };

  const handlePrint = () => {
    executePrint(
      `Receipt ${activeReceipt.id}`,
      'receipt',
      activeReceipt,
      activeReceipt.total
    );
  };

  const paymentMethods: Array<ReceiptData['paymentMethod']> = [
    'Cash',
    'Card',
    'UPI / Mobile',
    'Bank Transfer',
  ];

  return (
    <div className="max-w-6xl mx-auto pb-24 px-3 sm:px-4 pt-3 space-y-6">
      {/* Top Banner & Quick Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
            <Receipt className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                New Customer Receipt
              </h2>
              <span className="font-mono text-xs px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-semibold">
                {activeReceipt.id}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Configure items, dedicated fee, payment details, and instant print
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => {
              const newId = generateNewReceiptId();
              updateActiveReceipt({ id: newId });
            }}
            className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1 transition-colors"
            title="Generate a new receipt sequence number"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
            <span>Regen ID</span>
          </button>

          <button
            onClick={() => togglePaperWidth()}
            className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 transition-colors"
          >
            <Sliders className="w-3.5 h-3.5 text-emerald-600" />
            <span>Width: {printerSettings.paperWidth}</span>
          </button>

          <button
            onClick={resetReceipt}
            className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-600 dark:text-slate-400 flex items-center gap-1 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Main 2-Column Responsive Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Form Editor Column (7 Cols on desktop) */}
        <div className="lg:col-span-7 space-y-5">
          {/* Section 1: Customer & Transaction Meta */}
          <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <User className="w-4 h-4 text-emerald-600" />
              <span>Customer & Timestamp</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1 font-medium">Customer Name</label>
                <input
                  type="text"
                  placeholder="e.g. John Doe / Walk-in"
                  value={activeReceipt.customerName || ''}
                  onChange={(e) => updateActiveReceipt({ customerName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1 font-medium">Phone / Mobile</label>
                <input
                  type="text"
                  placeholder="+1 (555) 000-0000"
                  value={activeReceipt.customerPhone || ''}
                  onChange={(e) => updateActiveReceipt({ customerPhone: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1 font-medium">Receipt Date</label>
                <input
                  type="date"
                  value={activeReceipt.date}
                  onChange={(e) => updateActiveReceipt({ date: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1 font-medium">Time Stamp</label>
                <input
                  type="text"
                  value={activeReceipt.time}
                  onChange={(e) => updateActiveReceipt({ time: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Items & Services List */}
          <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Tag className="w-4 h-4 text-emerald-600" />
                <span>Line Items ({activeReceipt.items.length})</span>
              </h3>

              <span className="text-xs text-slate-500">
                Subtotal: <span className="font-bold text-slate-900 dark:text-white">{businessSettings.currencySymbol}{activeReceipt.subtotal.toFixed(2)}</span>
              </span>
            </div>

            {/* Quick Presets Carousel */}
            <div>
              <p className="text-[11px] text-slate-500 mb-1.5 font-medium">Quick Tap Items:</p>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {quickPresets.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => addItemToReceipt({ name: preset.name, unitPrice: preset.price, quantity: 1 })}
                    className="whitespace-nowrap px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-emerald-50 dark:bg-slate-800 dark:hover:bg-emerald-950/40 text-[11px] font-medium text-slate-700 dark:text-slate-300 hover:text-emerald-700 dark:hover:text-emerald-300 border border-slate-200/80 dark:border-slate-700 transition-colors shrink-0"
                  >
                    + {preset.name} ({businessSettings.currencySymbol}{preset.price})
                  </button>
                ))}
              </div>
            </div>

            {/* Add New Item Input Row */}
            <form onSubmit={handleAddNewItem} className="grid grid-cols-12 gap-2 pt-1">
              <input
                type="text"
                placeholder="Item name / service..."
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                className="col-span-6 sm:col-span-6 px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-emerald-500"
              />
              <input
                type="number"
                step="0.01"
                placeholder="Price"
                value={newItemPrice}
                onChange={(e) => setNewItemPrice(e.target.value)}
                className="col-span-3 sm:col-span-3 px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-emerald-500"
              />
              <input
                type="number"
                min="1"
                placeholder="Qty"
                value={newItemQty}
                onChange={(e) => setNewItemQty(e.target.value)}
                className="col-span-3 sm:col-span-1 px-2 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-center focus:outline-emerald-500"
              />
              <button
                type="submit"
                className="col-span-12 sm:col-span-2 h-9 px-3 rounded-xl bg-slate-900 dark:bg-emerald-600 hover:bg-slate-800 dark:hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1 transition-all"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </form>

            {/* Items List Table */}
            {activeReceipt.items.length > 0 && (
              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                {activeReceipt.items.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800 text-xs"
                  >
                    <div className="min-w-0 flex-1 pr-2">
                      <p className="font-semibold text-slate-900 dark:text-white truncate">{item.name}</p>
                      <p className="text-[11px] text-slate-500">
                        {item.quantity} × {businessSettings.currencySymbol}{item.unitPrice.toFixed(2)}
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold text-slate-900 dark:text-white">
                        {businessSettings.currencySymbol}{item.total.toFixed(2)}
                      </span>
                      <button
                        onClick={() => removeItemFromReceipt(item.id)}
                        className="w-7 h-7 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center justify-center transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section 3: DEDICATED FEE / AMOUNT RECEIVED FIELD & FINANCIALS */}
          <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-emerald-600" />
              <span>Dedicated Fee, Tax & Total Calculation</span>
            </h3>

            {/* DEDICATED FEE FIELD HIGHLIGHT BOX */}
            <div className="p-3.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-emerald-900 dark:text-emerald-300">
                  Dedicated Customer Fee / Amount
                </label>
                <span className="text-[11px] text-emerald-700 dark:text-emerald-400">
                  Printed directly on receipt
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1">Fee Label / Reason</label>
                  <input
                    type="text"
                    value={activeReceipt.feeLabel || ''}
                    placeholder="e.g. Service Fee / Handling Fee"
                    onChange={(e) => updateActiveReceipt({ feeLabel: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                    Fee Amount ({businessSettings.currencySymbol})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={activeReceipt.fee || ''}
                    placeholder="0.00"
                    onChange={(e) => updateActiveReceipt({ fee: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-xs font-bold"
                  />
                </div>
              </div>
            </div>

            {/* Tax & Discount */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">Tax Rate (%)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="100"
                  value={activeReceipt.taxPercent || ''}
                  onChange={(e) => updateActiveReceipt({ taxPercent: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">
                  Discount ({businessSettings.currencySymbol})
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={activeReceipt.discountAmount || ''}
                  onChange={(e) => updateActiveReceipt({ discountAmount: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-slate-900 dark:text-white"
                />
              </div>
            </div>

            {/* Payment Method Selector */}
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                Payment Method:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {paymentMethods.map((pm) => (
                  <button
                    key={pm}
                    type="button"
                    onClick={() => updateActiveReceipt({ paymentMethod: pm })}
                    className={`py-2 px-2.5 rounded-xl text-xs font-medium transition-all flex items-center justify-center gap-1.5 border ${
                      activeReceipt.paymentMethod === pm
                        ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-transparent shadow-xs'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {pm === 'Cash' && <Banknote className="w-3.5 h-3.5" />}
                    {pm === 'Card' && <CreditCard className="w-3.5 h-3.5" />}
                    {pm === 'UPI / Mobile' && <Smartphone className="w-3.5 h-3.5" />}
                    {pm === 'Bank Transfer' && <Layers className="w-3.5 h-3.5" />}
                    <span>{pm}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Customer Tender & Change Calculation */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                  Amount Received / Tendered ({businessSettings.currencySymbol})
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={activeReceipt.amountPaid || ''}
                  onChange={(e) => updateActiveReceipt({ amountPaid: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono font-bold text-emerald-600 dark:text-emerald-400 text-sm"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                  Change Due
                </label>
                <div className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono font-bold text-slate-900 dark:text-white text-sm">
                  {businessSettings.currencySymbol}{activeReceipt.changeDue.toFixed(2)}
                </div>
              </div>
            </div>

            {/* Receipt Notes */}
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                Custom Footer Note (Printed at bottom)
              </label>
              <input
                type="text"
                placeholder="e.g. Paid via Wallet ref #9281, non-refundable"
                value={activeReceipt.notes || ''}
                onChange={(e) => updateActiveReceipt({ notes: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Live Thermal Paper Roll Preview & Print CTA (5 Cols on desktop) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Thermal Paper Container */}
          <div className="bg-slate-200 dark:bg-slate-950 p-4 sm:p-6 rounded-3xl border border-slate-300 dark:border-slate-800 flex flex-col items-center">
            <div className="w-full flex items-center justify-between text-xs text-slate-500 font-mono mb-3 px-1">
              <span>THERMAL PAPER FEED</span>
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                {printerSettings.paperWidth} ({printerSettings.paperWidth === '58mm' ? '384 dots' : '576 dots'})
              </span>
            </div>

            {/* Live Rendered Receipt Paper */}
            <ThermalPaperPreview
              receipt={activeReceipt}
              business={businessSettings}
              paperWidth={printerSettings.paperWidth}
            />
          </div>

          {/* Primary Action Button (Print Instant) */}
          <div className="sticky bottom-20 z-20 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-lg">
            <button
              onClick={handlePrint}
              disabled={isPrinting}
              className="w-full h-13 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-all"
            >
              <Printer className="w-5 h-5" />
              <span>
                {isPrinting ? 'Feeding Thermal Roll...' : `Print Receipt (${businessSettings.currencySymbol}${activeReceipt.total.toFixed(2)})`}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
