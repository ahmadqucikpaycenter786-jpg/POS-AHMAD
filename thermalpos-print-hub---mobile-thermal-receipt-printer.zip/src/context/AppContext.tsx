import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import {
  PrinterSettings,
  BusinessSettings,
  ReceiptData,
  PrintHistoryItem,
  PaperWidth,
  ConnectionType,
  ConnectionStatus,
  ReceiptItem,
} from '../types';
import { thermalAudio } from '../utils/audio';

interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextType {
  // Printer & Business Settings
  printerSettings: PrinterSettings;
  updatePrinterSettings: (settings: Partial<PrinterSettings>) => void;
  businessSettings: BusinessSettings;
  updateBusinessSettings: (settings: Partial<BusinessSettings>) => void;
  togglePaperWidth: (width?: PaperWidth) => void;

  // Active Receipt
  activeReceipt: ReceiptData;
  updateActiveReceipt: (receipt: Partial<ReceiptData>) => void;
  addItemToReceipt: (item: Omit<ReceiptItem, 'id' | 'total'>) => void;
  removeItemFromReceipt: (id: string) => void;
  updateReceiptItem: (id: string, updates: Partial<ReceiptItem>) => void;
  resetReceipt: () => void;
  generateNewReceiptId: () => string;

  // Print execution & History
  printHistory: PrintHistoryItem[];
  lastPrintItem: PrintHistoryItem | null;
  executePrint: (title: string, type: PrintHistoryItem['type'], content: any, amount?: number) => Promise<boolean>;
  quickReprintLast: () => Promise<boolean>;
  reprintHistoryItem: (item: PrintHistoryItem) => Promise<boolean>;
  clearHistory: () => void;
  deleteHistoryItem: (id: string) => void;

  // Hardware connection actions
  connectPrinter: (type?: ConnectionType) => Promise<boolean>;
  disconnectPrinter: () => void;
  reconnectAttempts: number;

  // Navigation & UI
  activeTab: 'receipts' | 'scan_print' | 'qr_barcode' | 'history' | 'settings';
  setActiveTab: (tab: 'receipts' | 'scan_print' | 'qr_barcode' | 'history' | 'settings') => void;
  darkMode: boolean;
  setDarkMode: (enabled: boolean) => void;

  // Active Print Modal state
  isPrinting: boolean;
  printModalData: {
    isOpen: boolean;
    title: string;
    type: PrintHistoryItem['type'];
    content: any;
    paperWidth: PaperWidth;
  } | null;
  closePrintModal: () => void;

  // Toast
  toasts: ToastMessage[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const DEFAULT_PRINTER_SETTINGS: PrinterSettings = {
  paperWidth: '58mm',
  connectionType: 'bluetooth',
  autoReconnect: true,
  reconnectInterval: 5,
  maxReconnectAttempts: 5,
  wifiIp: '192.168.1.100',
  wifiPort: 9100,
  bluetoothDeviceName: 'POS-5802 Thermal BT',
  bluetoothDeviceId: 'BT:58:02:4A:89:C1',
  connectionStatus: 'connected',
  printDensity: 'normal',
  soundEnabled: true,
  feedLinesAfterPrint: 3,
  autoCut: true,
  beepOnPrint: true,
};

const DEFAULT_BUSINESS_SETTINGS: BusinessSettings = {
  shopName: 'AHMAD QUICK PAY & SERVICES',
  tagline: 'Fast, Reliable & Secure Transactions',
  logoUrl: '',
  logoType: 'icon',
  selectedIcon: 'Store',
  address: 'Shop #12, Ground Floor, Central City Plaza',
  phone: '+1 (555) 234-5678',
  taxId: 'TAX-8829-4109',
  cashierName: 'Ahmad M.',
  currencySymbol: '$',
  receiptIdPrefix: 'RCP-',
  receiptCounter: 1042,
  footerMessage: 'Thank you for your business!',
  disclaimer: 'Goods received in good order. Keep receipt for returns within 7 days.',
  showQrAtBottom: true,
  qrBottomContent: 'https://pay.example.com/receipt/verify?id=',
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Load saved state or default
  const [printerSettings, setPrinterSettings] = useState<PrinterSettings>(() => {
    try {
      const saved = localStorage.getItem('thermalpos_printer');
      return saved ? { ...DEFAULT_PRINTER_SETTINGS, ...JSON.parse(saved), connectionStatus: 'connected' } : DEFAULT_PRINTER_SETTINGS;
    } catch {
      return DEFAULT_PRINTER_SETTINGS;
    }
  });

  const [businessSettings, setBusinessSettings] = useState<BusinessSettings>(() => {
    try {
      const saved = localStorage.getItem('thermalpos_business');
      return saved ? { ...DEFAULT_BUSINESS_SETTINGS, ...JSON.parse(saved) } : DEFAULT_BUSINESS_SETTINGS;
    } catch {
      return DEFAULT_BUSINESS_SETTINGS;
    }
  });

  const [printHistory, setPrintHistory] = useState<PrintHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('thermalpos_history');
      if (saved) return JSON.parse(saved);
      // Seed with initial realistic demo print
      return [
        {
          id: 'hist-1',
          timestamp: Date.now() - 3600000 * 2,
          receiptId: 'RCP-1041',
          title: 'Mobile Bill & Voucher Payment',
          type: 'receipt',
          paperWidth: '58mm',
          connection: 'bluetooth',
          amount: 52.50,
          previewData: 'AHMAD QUICK PAY - Receipt #RCP-1041',
          rawContent: null,
          status: 'success',
          reprintCount: 0,
        },
      ];
    } catch {
      return [];
    }
  });

  const [activeTab, setActiveTab] = useState<'receipts' | 'scan_print' | 'qr_barcode' | 'history' | 'settings'>('receipts');
  const [reconnectAttempts, setReconnectAttempts] = useState(0);
  const [isPrinting, setIsPrinting] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [darkMode, setDarkModeState] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('thermalpos_dark');
      if (saved !== null) return JSON.parse(saved);
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  const [printModalData, setPrintModalData] = useState<{
    isOpen: boolean;
    title: string;
    type: PrintHistoryItem['type'];
    content: any;
    paperWidth: PaperWidth;
  } | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  }, []);

  const setDarkMode = useCallback((enabled: boolean) => {
    setDarkModeState(enabled);
    localStorage.setItem('thermalpos_dark', JSON.stringify(enabled));
    if (enabled) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  // Sync initial dark mode
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Save settings on update
  useEffect(() => {
    localStorage.setItem('thermalpos_printer', JSON.stringify(printerSettings));
  }, [printerSettings]);

  useEffect(() => {
    localStorage.setItem('thermalpos_business', JSON.stringify(businessSettings));
  }, [businessSettings]);

  useEffect(() => {
    localStorage.setItem('thermalpos_history', JSON.stringify(printHistory));
  }, [printHistory]);

  const updatePrinterSettings = useCallback((updates: Partial<PrinterSettings>) => {
    setPrinterSettings((prev) => ({ ...prev, ...updates }));
  }, []);

  const updateBusinessSettings = useCallback((updates: Partial<BusinessSettings>) => {
    setBusinessSettings((prev) => ({ ...prev, ...updates }));
  }, []);

  const togglePaperWidth = useCallback((newWidth?: PaperWidth) => {
    setPrinterSettings((prev) => {
      const width = newWidth || (prev.paperWidth === '58mm' ? '80mm' : '58mm');
      showToast(`Paper width set to ${width} thermal roll`, 'info');
      if (prev.soundEnabled) thermalAudio.playBuzzer(1800, 0.05);
      return { ...prev, paperWidth: width };
    });
  }, [showToast]);

  // Auto-generate fresh receipt ID
  const generateNewReceiptId = useCallback((): string => {
    const nextNum = businessSettings.receiptCounter + 1;
    updateBusinessSettings({ receiptCounter: nextNum });
    return `${businessSettings.receiptIdPrefix}${nextNum}`;
  }, [businessSettings.receiptCounter, businessSettings.receiptIdPrefix, updateBusinessSettings]);

  // Initial active receipt template
  const [activeReceipt, setActiveReceipt] = useState<ReceiptData>(() => {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().split(' ')[0];

    const initialItems: ReceiptItem[] = [
      { id: 'item-1', name: 'Mobile Recharge (50GB)', quantity: 1, unitPrice: 25.00, total: 25.00 },
      { id: 'item-2', name: 'Bill Processing Service', quantity: 1, unitPrice: 5.00, total: 5.00 },
    ];
    const subtotal = 30.00;
    const fee = 1.50; // Dedicated Fee / Amount received from customer
    const taxAmount = 1.50; // 5%
    const total = 33.00;

    return {
      id: `${DEFAULT_BUSINESS_SETTINGS.receiptIdPrefix}${DEFAULT_BUSINESS_SETTINGS.receiptCounter}`,
      date: dateStr,
      time: timeStr,
      items: initialItems,
      subtotal,
      taxPercent: 5,
      taxAmount,
      discountAmount: 0,
      fee,
      feeLabel: 'Service Fee',
      total,
      amountPaid: 35.00,
      changeDue: 2.00,
      paymentMethod: 'Cash',
      customerName: 'Ahmad QuickPay Walk-in',
      customerPhone: '+1 (555) 019-4829',
      notes: 'Payment confirmed. Account updated instantly.',
    };
  });

  const recalculateReceipt = useCallback((receipt: ReceiptData): ReceiptData => {
    const subtotal = receipt.items.reduce((acc, it) => acc + it.total, 0);
    const taxAmount = (subtotal * (receipt.taxPercent || 0)) / 100;
    const fee = Number(receipt.fee) || 0;
    const discount = Number(receipt.discountAmount) || 0;
    const total = Math.max(0, subtotal + taxAmount + fee - discount);
    const paid = Number(receipt.amountPaid) || 0;
    const changeDue = Math.max(0, paid - total);

    return {
      ...receipt,
      subtotal,
      taxAmount,
      total,
      changeDue,
    };
  }, []);

  const updateActiveReceipt = useCallback((updates: Partial<ReceiptData>) => {
    setActiveReceipt((prev) => {
      const merged = { ...prev, ...updates };
      return recalculateReceipt(merged);
    });
  }, [recalculateReceipt]);

  const addItemToReceipt = useCallback((itemData: Omit<ReceiptItem, 'id' | 'total'>) => {
    setActiveReceipt((prev) => {
      const total = itemData.quantity * itemData.unitPrice;
      const newItem: ReceiptItem = {
        id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        ...itemData,
        total,
      };
      const newItems = [...prev.items, newItem];
      return recalculateReceipt({ ...prev, items: newItems });
    });
  }, [recalculateReceipt]);

  const removeItemFromReceipt = useCallback((id: string) => {
    setActiveReceipt((prev) => {
      const newItems = prev.items.filter((it) => it.id !== id);
      return recalculateReceipt({ ...prev, items: newItems });
    });
  }, [recalculateReceipt]);

  const updateReceiptItem = useCallback((id: string, updates: Partial<ReceiptItem>) => {
    setActiveReceipt((prev) => {
      const newItems = prev.items.map((it) => {
        if (it.id === id) {
          const updated = { ...it, ...updates };
          updated.total = updated.quantity * updated.unitPrice;
          return updated;
        }
        return it;
      });
      return recalculateReceipt({ ...prev, items: newItems });
    });
  }, [recalculateReceipt]);

  const resetReceipt = useCallback(() => {
    const now = new Date();
    const newId = generateNewReceiptId();
    setActiveReceipt({
      id: newId,
      date: now.toISOString().split('T')[0],
      time: now.toTimeString().split(' ')[0],
      items: [],
      subtotal: 0,
      taxPercent: 0,
      taxAmount: 0,
      discountAmount: 0,
      fee: 0,
      feeLabel: 'Service Fee',
      total: 0,
      amountPaid: 0,
      changeDue: 0,
      paymentMethod: 'Cash',
      customerName: '',
      customerPhone: '',
      notes: '',
    });
    showToast('New blank receipt created', 'info');
  }, [generateNewReceiptId, showToast]);

  // Connect printer handler with realistic Web Bluetooth & Wi-Fi simulation
  const connectPrinter = useCallback(async (type?: ConnectionType): Promise<boolean> => {
    const connType = type || printerSettings.connectionType;
    updatePrinterSettings({ connectionType: connType, connectionStatus: 'connecting' });
    showToast(`Connecting to ${connType.toUpperCase()} printer...`, 'info');

    if (printerSettings.soundEnabled) {
      thermalAudio.playBuzzer(1600, 0.08);
    }

    try {
      if (connType === 'bluetooth' && typeof navigator !== 'undefined' && 'bluetooth' in navigator) {
        // Real Web Bluetooth request trigger if available in browser
        // If user cancels or browser restricts inside iframe, we seamlessly fall back to virtual/paired profile
        try {
          const device = await (navigator as any).bluetooth.requestDevice({
            acceptAllDevices: true,
            optionalServices: ['000018f0-0000-1000-8000-00805f9b34fb', 'e7810a71-73ae-499d-8c15-faa9aef0c3f2', 'battery_service'],
          });
          updatePrinterSettings({
            bluetoothDeviceName: device.name || 'Thermal POS Printer',
            bluetoothDeviceId: device.id || 'BT:DEV:PAIRED',
            connectionStatus: 'connected',
          });
          setReconnectAttempts(0);
          showToast(`Bluetooth Printer "${device.name || 'Thermal POS'}" connected!`, 'success');
          if (printerSettings.soundEnabled) thermalAudio.playSuccessChime();
          return true;
        } catch {
          // Fall back to stored profile
        }
      }

      // Simulated connection delay for smooth UI feedback
      await new Promise((r) => setTimeout(r, 900));

      updatePrinterSettings({ connectionStatus: 'connected' });
      setReconnectAttempts(0);
      showToast(`${connType === 'wifi' ? 'Wi-Fi Network' : 'Bluetooth'} printer connected!`, 'success');
      if (printerSettings.soundEnabled) thermalAudio.playSuccessChime();
      return true;
    } catch {
      updatePrinterSettings({ connectionStatus: 'disconnected' });
      showToast('Printer connection failed', 'error');
      if (printerSettings.soundEnabled) thermalAudio.playErrorTone();
      return false;
    }
  }, [printerSettings.connectionType, printerSettings.soundEnabled, showToast, updatePrinterSettings]);

  const disconnectPrinter = useCallback(() => {
    updatePrinterSettings({ connectionStatus: 'disconnected' });
    showToast('Printer disconnected', 'info');
    if (printerSettings.soundEnabled) thermalAudio.playErrorTone();
  }, [printerSettings.soundEnabled, showToast, updatePrinterSettings]);

  // Auto-reconnect cycle
  useEffect(() => {
    if (!printerSettings.autoReconnect) return;
    if (printerSettings.connectionStatus !== 'disconnected') return;
    if (reconnectAttempts >= printerSettings.maxReconnectAttempts) return;

    const timer = setTimeout(() => {
      setReconnectAttempts((prev) => prev + 1);
      updatePrinterSettings({ connectionStatus: 'reconnecting' });
      showToast(`Auto-reconnecting attempt ${reconnectAttempts + 1}/${printerSettings.maxReconnectAttempts}...`, 'info');

      setTimeout(() => {
        // Auto-reconnect successfully
        updatePrinterSettings({ connectionStatus: 'connected' });
        setReconnectAttempts(0);
        showToast('Auto-reconnected to thermal printer!', 'success');
        if (printerSettings.soundEnabled) thermalAudio.playSuccessChime();
      }, 1200);
    }, printerSettings.reconnectInterval * 1000);

    return () => clearTimeout(timer);
  }, [
    printerSettings.autoReconnect,
    printerSettings.connectionStatus,
    printerSettings.maxReconnectAttempts,
    printerSettings.reconnectInterval,
    printerSettings.soundEnabled,
    reconnectAttempts,
    showToast,
    updatePrinterSettings,
  ]);

  // Execute Print
  const executePrint = useCallback(
    async (
      title: string,
      type: PrintHistoryItem['type'],
      content: any,
      amount?: number
    ): Promise<boolean> => {
      setIsPrinting(true);

      // Play thermal head motor sound & buzzer
      if (printerSettings.soundEnabled) {
        if (printerSettings.beepOnPrint) thermalAudio.playBuzzer(2400, 0.1);
        thermalAudio.playPrintFeedSound(1.4);
      }

      // Open print visualizer modal
      setPrintModalData({
        isOpen: true,
        title,
        type,
        content,
        paperWidth: printerSettings.paperWidth,
      });

      // Register into Print History
      const historyItem: PrintHistoryItem = {
        id: `print-${Date.now()}`,
        timestamp: Date.now(),
        receiptId: content?.id || (type === 'receipt' ? activeReceipt.id : `PRN-${Math.floor(Math.random() * 90000 + 10000)}`),
        title,
        type,
        paperWidth: printerSettings.paperWidth,
        connection: printerSettings.connectionType,
        amount: amount !== undefined ? amount : (content?.total ?? 0),
        previewData: typeof content === 'string' ? content.slice(0, 120) : title,
        rawContent: content,
        status: 'success',
        reprintCount: 0,
      };

      setPrintHistory((prev) => [historyItem, ...prev]);

      // If it's a new receipt, auto advance the receipt counter
      if (type === 'receipt') {
        const nextId = generateNewReceiptId();
        setActiveReceipt((prev) => ({
          ...prev,
          id: nextId,
        }));
      }

      setTimeout(() => {
        setIsPrinting(false);
      }, 1500);

      return true;
    },
    [
      activeReceipt.id,
      generateNewReceiptId,
      printerSettings.beepOnPrint,
      printerSettings.connectionType,
      printerSettings.paperWidth,
      printerSettings.soundEnabled,
    ]
  );

  // Quick Reprint Last Receipt
  const lastPrintItem = printHistory.length > 0 ? printHistory[0] : null;

  const quickReprintLast = useCallback(async (): Promise<boolean> => {
    if (!lastPrintItem) {
      showToast('No previous prints found in history to reprint', 'error');
      return false;
    }

    showToast(`Quick Reprinting: ${lastPrintItem.title} (${lastPrintItem.receiptId})`, 'info');

    // Update reprint count on the item
    setPrintHistory((prev) =>
      prev.map((item, idx) =>
        idx === 0 ? { ...item, reprintCount: (item.reprintCount || 0) + 1 } : item
      )
    );

    const duplicateContent = lastPrintItem.type === 'receipt' && typeof lastPrintItem.rawContent === 'object'
      ? { ...lastPrintItem.rawContent, isReprint: true }
      : lastPrintItem.rawContent;

    return executePrint(
      `[Reprint] ${lastPrintItem.title}`,
      lastPrintItem.type,
      duplicateContent,
      lastPrintItem.amount
    );
  }, [executePrint, lastPrintItem, showToast]);

  const reprintHistoryItem = useCallback(
    async (item: PrintHistoryItem): Promise<boolean> => {
      showToast(`Reprinting ${item.receiptId}...`, 'info');
      setPrintHistory((prev) =>
        prev.map((it) => (it.id === item.id ? { ...it, reprintCount: (it.reprintCount || 0) + 1 } : it))
      );

      const duplicateContent = item.type === 'receipt' && typeof item.rawContent === 'object'
        ? { ...item.rawContent, isReprint: true }
        : item.rawContent;

      return executePrint(`[Reprint] ${item.title}`, item.type, duplicateContent, item.amount);
    },
    [executePrint, showToast]
  );

  const clearHistory = useCallback(() => {
    setPrintHistory([]);
    showToast('Print history cleared', 'info');
  }, [showToast]);

  const deleteHistoryItem = useCallback((id: string) => {
    setPrintHistory((prev) => prev.filter((item) => item.id !== id));
    showToast('Record deleted from history', 'info');
  }, [showToast]);

  const closePrintModal = useCallback(() => {
    setPrintModalData(null);
  }, []);

  return (
    <AppContext.Provider
      value={{
        printerSettings,
        updatePrinterSettings,
        businessSettings,
        updateBusinessSettings,
        togglePaperWidth,
        activeReceipt,
        updateActiveReceipt,
        addItemToReceipt,
        removeItemFromReceipt,
        updateReceiptItem,
        resetReceipt,
        generateNewReceiptId,
        printHistory,
        lastPrintItem,
        executePrint,
        quickReprintLast,
        reprintHistoryItem,
        clearHistory,
        deleteHistoryItem,
        connectPrinter,
        disconnectPrinter,
        reconnectAttempts,
        activeTab,
        setActiveTab,
        darkMode,
        setDarkMode,
        isPrinting,
        printModalData,
        closePrintModal,
        toasts,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
