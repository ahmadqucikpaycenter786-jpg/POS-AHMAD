export type PaperWidth = '58mm' | '80mm';

export type ConnectionType = 'bluetooth' | 'wifi';

export type ConnectionStatus = 'connected' | 'connecting' | 'disconnected' | 'reconnecting';

export interface PrinterSettings {
  paperWidth: PaperWidth;
  connectionType: ConnectionType;
  autoReconnect: boolean;
  reconnectInterval: number; // in seconds (e.g. 5)
  maxReconnectAttempts: number;
  wifiIp: string;
  wifiPort: number;
  bluetoothDeviceName: string;
  bluetoothDeviceId: string;
  connectionStatus: ConnectionStatus;
  printDensity: 'light' | 'normal' | 'dark';
  soundEnabled: boolean;
  feedLinesAfterPrint: number;
  autoCut: boolean;
  beepOnPrint: boolean;
}

export interface BusinessSettings {
  shopName: string;
  tagline: string;
  logoUrl: string; // custom base64 or SVG
  logoType: 'none' | 'icon' | 'custom';
  selectedIcon: string;
  address: string;
  phone: string;
  taxId: string; // GST/VAT/Tax number
  cashierName: string;
  currencySymbol: string;
  receiptIdPrefix: string;
  receiptCounter: number;
  footerMessage: string;
  disclaimer: string;
  showQrAtBottom: boolean;
  qrBottomContent: string;
}

export interface ReceiptItem {
  id: string;
  name: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface ReceiptData {
  id: string; // Auto-generated e.g. RCP-10294
  date: string; // YYYY-MM-DD
  time: string; // HH:mm:ss
  items: ReceiptItem[];
  subtotal: number;
  taxPercent: number;
  taxAmount: number;
  discountAmount: number;
  fee: number; // Dedicated field for Service/Processing/Custom Fee received
  feeLabel: string; // e.g. "Service Fee", "Delivery Fee", "Convenience Fee"
  total: number;
  amountPaid: number;
  changeDue: number;
  paymentMethod: 'Cash' | 'Card' | 'UPI / Mobile' | 'Bank Transfer';
  customerName?: string;
  customerPhone?: string;
  notes?: string;
  isReprint?: boolean;
}

export type PrintContentType = 'receipt' | 'bw_image' | 'ocr_text' | 'barcode_qr';

export interface PrintHistoryItem {
  id: string;
  timestamp: number;
  receiptId: string;
  title: string;
  type: PrintContentType;
  paperWidth: PaperWidth;
  connection: ConnectionType;
  amount?: number;
  previewData?: string; // image thumbnail or snippet
  rawContent: any; // payload used to reprint exactly
  status: 'success' | 'failed';
  reprintCount: number;
}

export interface CropArea {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface ImageProcessingOptions {
  ditherType: 'floyd_steinberg' | 'atkinson' | 'threshold';
  threshold: number; // 0-255
  contrast: number; // -100 to 100
  brightness: number; // -100 to 100
  invert: boolean;
  rotation: number; // 0, 90, 180, 270
}

export interface BarcodeQrConfig {
  type: 'qr' | 'barcode';
  format: 'CODE128' | 'EAN13' | 'EAN8' | 'UPC' | 'CODE39' | 'QR';
  content: string;
  caption: string;
  size: number; // 1 to 5 scale
  showLabel: boolean;
  align: 'left' | 'center' | 'right';
  errorCorrection: 'L' | 'M' | 'Q' | 'H';
}
