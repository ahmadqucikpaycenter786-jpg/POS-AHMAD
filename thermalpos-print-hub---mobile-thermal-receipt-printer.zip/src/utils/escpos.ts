import { PaperWidth, ReceiptData, BusinessSettings } from '../types';
import { getPrinterDotWidth } from './dithering';

export class EscPosBuilder {
  private buffer: number[] = [];

  constructor() {
    this.init();
  }

  public init(): this {
    // ESC @ : Initialize printer
    this.buffer.push(0x1b, 0x40);
    return this;
  }

  public align(alignment: 'left' | 'center' | 'right'): this {
    // ESC a n : 0 = left, 1 = center, 2 = right
    const n = alignment === 'left' ? 0 : alignment === 'center' ? 1 : 2;
    this.buffer.push(0x1b, 0x61, n);
    return this;
  }

  public bold(enabled: boolean): this {
    // ESC E n : 1 = bold, 0 = normal
    this.buffer.push(0x1b, 0x45, enabled ? 1 : 0);
    return this;
  }

  public underline(enabled: boolean): this {
    // ESC - n : 1 = underline
    this.buffer.push(0x1b, 0x2d, enabled ? 1 : 0);
    return this;
  }

  public textSize(widthMultiplier: 1 | 2 = 1, heightMultiplier: 1 | 2 = 1): this {
    // GS ! n : bits 0-3 height (0=1x, 1=2x), bits 4-7 width (0=1x, 1=2x)
    const n = ((widthMultiplier - 1) << 4) | (heightMultiplier - 1);
    this.buffer.push(0x1d, 0x21, n);
    return this;
  }

  public text(str: string): this {
    // Convert string to ASCII bytes
    for (let i = 0; i < str.length; i++) {
      const code = str.charCodeAt(i);
      this.buffer.push(code > 127 ? 0x20 : code);
    }
    return this;
  }

  public line(str = ''): this {
    this.text(str);
    this.buffer.push(0x0a); // LF
    return this;
  }

  public feed(lines = 1): this {
    // ESC d n
    this.buffer.push(0x1b, 0x64, lines);
    return this;
  }

  public beep(): this {
    // ESC B n t : Beep buzzer
    this.buffer.push(0x1b, 0x42, 2, 2);
    return this;
  }

  public cut(partial = false): this {
    // Feed 3 lines first then cut
    this.feed(3);
    // GS V m : 65 = full cut, 66 = partial cut
    this.buffer.push(0x1d, 0x56, partial ? 66 : 65, 0);
    return this;
  }

  /**
   * Print 1-bit raster image (GS v 0)
   */
  public rasterBitImage(bitmap: Uint8Array, widthDots: number, heightDots: number): this {
    const bytesPerLine = Math.ceil(widthDots / 8);
    const xL = bytesPerLine % 256;
    const xH = Math.floor(bytesPerLine / 256);
    const yL = heightDots % 256;
    const yH = Math.floor(heightDots / 256);

    // GS v 0 m xL xH yL yH data...
    // m = 0 (normal density)
    this.buffer.push(0x1d, 0x76, 0x30, 0, xL, xH, yL, yH);

    for (let i = 0; i < bitmap.length; i++) {
      this.buffer.push(bitmap[i]);
    }

    return this;
  }

  /**
   * Helper to format a 2-column key-value row with dots or spaces filler
   */
  public keyValue(key: string, value: string, maxChars: number, filler = ' '): this {
    const availableSpace = maxChars - key.length - value.length;
    if (availableSpace <= 0) {
      this.line(`${key} ${value}`);
    } else {
      const padding = filler.repeat(availableSpace);
      this.line(`${key}${padding}${value}`);
    }
    return this;
  }

  /**
   * Print a divider line (e.g. "--------------------------------")
   */
  public divider(char = '-', maxChars: number): this {
    this.line(char.repeat(maxChars));
    return this;
  }

  public build(): Uint8Array {
    return new Uint8Array(this.buffer);
  }

  public toHexDump(): string {
    return Array.from(this.buffer)
      .map((b) => b.toString(16).padStart(2, '0').toUpperCase())
      .join(' ');
  }
}

/**
 * Calculates max characters per line for standard 203 DPI thermal printers:
 * 58mm: Font A (12x24) = 32 chars/line
 * 80mm: Font A (12x24) = 48 chars/line
 */
export function getMaxCharsPerLine(paperWidth: PaperWidth): number {
  return paperWidth === '58mm' ? 32 : 48;
}

/**
 * Builds complete ESC/POS binary command stream for a structured receipt
 */
export function buildReceiptEscPos(
  receipt: ReceiptData,
  business: BusinessSettings,
  paperWidth: PaperWidth
): Uint8Array {
  const maxChars = getMaxCharsPerLine(paperWidth);
  const builder = new EscPosBuilder();

  // Header
  builder.align('center');
  if (receipt.isReprint) {
    builder.bold(true).line('*** DUPLICATE / REPRINT ***').bold(false);
  }

  builder.bold(true).textSize(2, 2).line(business.shopName).textSize(1, 1).bold(false);

  if (business.tagline) {
    builder.line(business.tagline);
  }
  if (business.address) {
    builder.line(business.address);
  }
  if (business.phone) {
    builder.line(`Tel: ${business.phone}`);
  }
  if (business.taxId) {
    builder.line(`Tax/GST ID: ${business.taxId}`);
  }

  builder.divider('-', maxChars);

  // Meta info
  builder.align('left');
  builder.keyValue(`Receipt #: ${receipt.id}`, `${receipt.date}`, maxChars);
  builder.keyValue(`Time: ${receipt.time}`, `Cashier: ${business.cashierName || 'Admin'}`, maxChars);

  if (receipt.customerName) {
    builder.line(`Customer: ${receipt.customerName}`);
  }

  builder.divider('=', maxChars);

  // Table header
  if (paperWidth === '58mm') {
    // Compact: Item x Qty   Price
    builder.bold(true).line('ITEM / QTY                TOTAL').bold(false);
  } else {
    // 80mm wide: ITEM NAME           QTY    PRICE    TOTAL
    builder.bold(true).line('ITEM NAME                  QTY    PRICE    TOTAL').bold(false);
  }
  builder.divider('-', maxChars);

  // Line Items
  receipt.items.forEach((item) => {
    const qtyStr = `${item.quantity}x @${business.currencySymbol}${item.unitPrice.toFixed(2)}`;
    const totalStr = `${business.currencySymbol}${item.total.toFixed(2)}`;

    if (paperWidth === '58mm') {
      builder.bold(true).line(item.name).bold(false);
      builder.keyValue(` ${qtyStr}`, totalStr, maxChars);
    } else {
      // 48 columns
      const namePart = item.name.padEnd(26).slice(0, 26);
      const qtyPart = String(item.quantity).padStart(5);
      const pricePart = `${business.currencySymbol}${item.unitPrice.toFixed(2)}`.padStart(8);
      const totalPart = `${business.currencySymbol}${item.total.toFixed(2)}`.padStart(9);
      builder.line(`${namePart}${qtyPart}${pricePart}${totalPart}`);
    }
  });

  builder.divider('-', maxChars);

  // Totals & Fee
  builder.align('right');
  builder.keyValue('Subtotal:', `${business.currencySymbol}${receipt.subtotal.toFixed(2)}`, maxChars);

  if (receipt.taxAmount > 0) {
    builder.keyValue(`Tax (${receipt.taxPercent}%):`, `${business.currencySymbol}${receipt.taxAmount.toFixed(2)}`, maxChars);
  }
  if (receipt.discountAmount > 0) {
    builder.keyValue('Discount:', `-${business.currencySymbol}${receipt.discountAmount.toFixed(2)}`, maxChars);
  }

  // DEDICATED FEE / AMOUNT FIELD
  if (receipt.fee > 0) {
    builder.keyValue(`${receipt.feeLabel || 'Fee / Surcharge'}:`, `+${business.currencySymbol}${receipt.fee.toFixed(2)}`, maxChars);
  }

  builder.divider('=', maxChars);

  // Grand Total in double height/width
  builder.bold(true).textSize(1, 2);
  builder.keyValue('TOTAL:', `${business.currencySymbol}${receipt.total.toFixed(2)}`, maxChars);
  builder.textSize(1, 1).bold(false);

  builder.divider('-', maxChars);

  // Payment Breakdown
  builder.keyValue(`Paid (${receipt.paymentMethod}):`, `${business.currencySymbol}${receipt.amountPaid.toFixed(2)}`, maxChars);
  if (receipt.changeDue > 0) {
    builder.bold(true).keyValue('Change Due:', `${business.currencySymbol}${receipt.changeDue.toFixed(2)}`, maxChars).bold(false);
  }

  // Footer
  builder.feed(1);
  builder.align('center');
  if (business.footerMessage) {
    builder.line(business.footerMessage);
  }
  if (business.disclaimer) {
    builder.line(business.disclaimer);
  }

  builder.line('--- Thank You ---');
  builder.feed(2);
  builder.cut(false);

  return builder.build();
}
