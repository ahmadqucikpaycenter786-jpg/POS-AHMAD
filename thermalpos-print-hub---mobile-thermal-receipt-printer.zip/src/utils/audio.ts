/**
 * Synthesizes realistic thermal printer audio feedback using the Web Audio API.
 * No external audio files required!
 */

class ThermalSoundEngine {
  private ctx: AudioContext | null = null;

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  /**
   * Classic thermal printer piezo buzzer beep (ESC B)
   */
  public playBuzzer(frequency = 2400, duration = 0.12): void {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(frequency, ctx.currentTime);

      gain.gain.setValueAtTime(0.25, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {
      // Audio autoplay policy fallback
    }
  }

  /**
   * Double beep indicating successful connection or print finish
   */
  public playSuccessChime(): void {
    this.playBuzzer(2100, 0.08);
    setTimeout(() => {
      this.playBuzzer(2700, 0.12);
    }, 110);
  }

  /**
   * Lower tone buzz for disconnection or error
   */
  public playErrorTone(): void {
    this.playBuzzer(480, 0.25);
    setTimeout(() => {
      this.playBuzzer(360, 0.35);
    }, 180);
  }

  /**
   * Synthesize mechanical stepper motor paper feeding sound
   */
  public playPrintFeedSound(durationSec = 1.2): void {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      // Periodic clicks + subtle motor hum
      const bufferSize = ctx.sampleRate * Math.min(durationSec, 3);
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);

      // Thermal head stepper pulse frequency ~150Hz
      const stepInterval = Math.floor(ctx.sampleRate / 140);
      for (let i = 0; i < bufferSize; i++) {
        const isPulse = (i % stepInterval) < 4;
        const noise = (Math.random() * 2 - 1) * 0.15;
        data[i] = isPulse ? 0.35 + noise : noise * 0.1;
      }

      const noiseSource = ctx.createBufferSource();
      noiseSource.buffer = buffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1200, ctx.currentTime);
      filter.Q.setValueAtTime(2.0, ctx.currentTime);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.18, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.18, ctx.currentTime + durationSec - 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + durationSec);

      noiseSource.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      noiseSource.start();
      noiseSource.stop(ctx.currentTime + durationSec);
    } catch {
      // audio fallback
    }
  }
}

export const thermalAudio = new ThermalSoundEngine();
