import { ImageProcessingOptions, PaperWidth } from '../types';

export interface ProcessedImageData {
  canvas: HTMLCanvasElement;
  dataUrl: string;
  width: number;
  height: number;
  dotsPerLine: number;
  bitmapData: Uint8Array; // 1 bit per dot packed for ESC/POS GS v 0
}

/**
 * Returns physical dot width for standard thermal heads:
 * 58mm: 384 dots (48mm printable area at 203 DPI / 8 dots/mm)
 * 80mm: 576 dots (72mm printable area at 203 DPI / 8 dots/mm)
 */
export function getPrinterDotWidth(paperWidth: PaperWidth): number {
  return paperWidth === '58mm' ? 384 : 576;
}

/**
 * Process any image source (HTMLImageElement, Canvas, or ImageBitmap) into
 * 1-bit monochrome bitmap tailored specifically for thermal receipt print heads.
 */
export function processThermalMonochrome(
  sourceImage: CanvasImageSource,
  sourceWidth: number,
  sourceHeight: number,
  paperWidth: PaperWidth,
  options: ImageProcessingOptions
): ProcessedImageData {
  const targetWidth = getPrinterDotWidth(paperWidth);
  // Maintain aspect ratio
  const targetHeight = Math.max(1, Math.round((sourceHeight / sourceWidth) * targetWidth));

  const offscreenCanvas = document.createElement('canvas');
  offscreenCanvas.width = targetWidth;
  offscreenCanvas.height = targetHeight;
  const ctx = offscreenCanvas.getContext('2d', { willReadFrequently: true });

  if (!ctx) {
    throw new Error('Canvas 2D context not available');
  }

  // Draw background white first
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, targetWidth, targetHeight);

  // Apply rotation if needed
  if (options.rotation !== 0) {
    ctx.save();
    ctx.translate(targetWidth / 2, targetHeight / 2);
    ctx.rotate((options.rotation * Math.PI) / 180);
    ctx.drawImage(sourceImage, -targetWidth / 2, -targetHeight / 2, targetWidth, targetHeight);
    ctx.restore();
  } else {
    ctx.drawImage(sourceImage, 0, 0, targetWidth, targetHeight);
  }

  const imgData = ctx.getImageData(0, 0, targetWidth, targetHeight);
  const data = imgData.data;

  // Convert to grayscale with contrast & brightness adjust
  const brightness = options.brightness; // -100 to 100
  const contrastFactor = (259 * (options.contrast + 255)) / (255 * (259 - options.contrast));

  const gray = new Float32Array(targetWidth * targetHeight);

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    // Standard Rec. 601 luma
    let lum = 0.299 * r + 0.587 * g + 0.114 * b;

    // Apply brightness
    lum += (brightness / 100) * 255;

    // Apply contrast
    lum = contrastFactor * (lum - 128) + 128;
    lum = Math.max(0, Math.min(255, lum));

    if (options.invert) {
      lum = 255 - lum;
    }

    gray[i / 4] = lum;
  }

  // Apply selected Dither Algorithm
  const thresholdVal = options.threshold; // default ~128

  if (options.ditherType === 'threshold') {
    // Direct 1-bit thresholding (cleanest for receipts, text, tables)
    for (let i = 0; i < gray.length; i++) {
      gray[i] = gray[i] < thresholdVal ? 0 : 255;
    }
  } else if (options.ditherType === 'floyd_steinberg') {
    // Floyd-Steinberg error diffusion
    for (let y = 0; y < targetHeight; y++) {
      for (let x = 0; x < targetWidth; x++) {
        const idx = y * targetWidth + x;
        const oldPixel = gray[idx];
        const newPixel = oldPixel < thresholdVal ? 0 : 255;
        gray[idx] = newPixel;
        const quantError = oldPixel - newPixel;

        if (x + 1 < targetWidth) {
          gray[idx + 1] += quantError * (7 / 16);
        }
        if (x - 1 >= 0 && y + 1 < targetHeight) {
          gray[idx + targetWidth - 1] += quantError * (3 / 16);
        }
        if (y + 1 < targetHeight) {
          gray[idx + targetWidth] += quantError * (5 / 16);
        }
        if (x + 1 < targetWidth && y + 1 < targetHeight) {
          gray[idx + targetWidth + 1] += quantError * (1 / 16);
        }
      }
    }
  } else if (options.ditherType === 'atkinson') {
    // Atkinson Dithering (used in early Mac & Game Boy printer)
    for (let y = 0; y < targetHeight; y++) {
      for (let x = 0; x < targetWidth; x++) {
        const idx = y * targetWidth + x;
        const oldPixel = gray[idx];
        const newPixel = oldPixel < thresholdVal ? 0 : 255;
        gray[idx] = newPixel;
        const quantError = Math.floor((oldPixel - newPixel) / 8);

        if (x + 1 < targetWidth) gray[idx + 1] += quantError;
        if (x + 2 < targetWidth) gray[idx + 2] += quantError;
        if (x - 1 >= 0 && y + 1 < targetHeight) gray[idx + targetWidth - 1] += quantError;
        if (y + 1 < targetHeight) gray[idx + targetWidth] += quantError;
        if (x + 1 < targetWidth && y + 1 < targetHeight) gray[idx + targetWidth + 1] += quantError;
        if (y + 2 < targetHeight) gray[idx + 2 * targetWidth] += quantError;
      }
    }
  }

  // Pack into 1-bit monochrome bytes for ESC/POS (GS v 0)
  // Each byte contains 8 horizontal pixels (MSB first: bit 7 is leftmost)
  // 0 = white, 1 = black (thermal head heats up)
  const bytesPerLine = Math.ceil(targetWidth / 8);
  const bitmapData = new Uint8Array(bytesPerLine * targetHeight);

  // Write back to canvas for display preview
  for (let y = 0; y < targetHeight; y++) {
    for (let x = 0; x < targetWidth; x++) {
      const idx = y * targetWidth + x;
      const isBlack = gray[idx] <= 127;
      const pixelIndex = idx * 4;

      const val = isBlack ? 0 : 255;
      data[pixelIndex] = val;
      data[pixelIndex + 1] = val;
      data[pixelIndex + 2] = val;
      data[pixelIndex + 3] = 255;

      if (isBlack) {
        const byteIndex = y * bytesPerLine + Math.floor(x / 8);
        const bitOffset = 7 - (x % 8);
        bitmapData[byteIndex] |= 1 << bitOffset;
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);

  return {
    canvas: offscreenCanvas,
    dataUrl: offscreenCanvas.toDataURL('image/png'),
    width: targetWidth,
    height: targetHeight,
    dotsPerLine: targetWidth,
    bitmapData,
  };
}
